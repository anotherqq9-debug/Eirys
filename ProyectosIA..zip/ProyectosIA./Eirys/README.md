# 🏛️ PROYECTO EIRYS: ARQUITECTURA DE SIMULACIÓN Y CONTROL NARRATIVO

> **Directorio Raíz:** `/home/vola3s/Documentos/Proyectos IA./Eirys`  
> **Versión del Framework:** Eirys 1.0 (GentlemanProgram 4.2 Integrado)  
> **Estado:** Operativo y Desacoplado (Punto Cero)

---

## 📂 MAPA DE DIRECTORIOS DEL SISTEMA

```
Eirys/
├── Personaje/             # Dossier del protagonista y directivas de privacidad
├── Escenario/             # Parámetros del entorno físico, bioma, visibilidad y terreno
├── Reloj/                 # Motor cronológico, calendario y avance temporal sin saltos
├── Inventario/            # Fuente única de verdad económica (tesorería exacta) y equipo
├── Mapa o GPS/            # Cartografía continental, coordenadas y distancias en km
├── NPC/                   # Fichas activas, límites cognitivos y archivo histórico
├── Red Social/            # Matriz de lealtades, afinidad y organigrama político
├── Reglas/                # Compendio maestro de leyes inmutables y guardrails
└── Programs/              # Suites técnicas y motores de auditoría
    ├── Historial Narrativo Positivo/ # Hechos admitidos al canon y certificaciones
    ├── Historial Narrativo Negativo/ # Registro de anomalías y soluciones
    ├── UI/                           # Panel de estado interactivo (HTML/Tailwind)
    ├── bin/                          # Binarios nativos (engram, gentle-ai)
    ├── GentlemanProgram/             # Detector de fallas y comprobación automatizada
    ├── core/                         # Scripts de orquestación y sincronización
    └── configuraciones/              # Configuración persistente (engram, gentle-protocol)
```
