# 📁 BASE DE DATOS MAESTRA DE NPCS Y MATRIZ SOCIAL-POLÍTICA (LAB_02)

---

## 🎯 OBJETIVO DEL SISTEMA
Esta base de datos descentralizada y estructurada garantiza la **coherencia nominativa, jerárquica y relacional absoluta** de todos los Personajes No Jugadores (NPCs) en la narrativa de *LAB_02 (Log Horizon)*.
Previene amnesias cruzadas, confusiones de nombres o roles (e.g. diferenciar nítidamente a la **Recepcionista Sora** de la **Reclutadora Yumi**), y asegura que cada líder o funcionario recuerde con exactitud a sus subordinados y pares políticos.

---

## 🏛️ ESTRUCTURA DE ARCHIVOS DE LA BASE DE DATOS

| Archivo / Ficha | Nombre del NPC | Raza / Estatus | Función Institucional / Jerarquía |
| :--- | :--- | :--- | :--- |
| [`01_aoi.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/01_aoi.md) | **Aoi** | Mestiza Elfa | **Maga de Combate Rango C+ Élite** (Primera Compañera de Log Horizon) |
| [`02_kohaku.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/02_kohaku.md) | **Kohaku** | Demihumana Kitsune | **Curadora Mágica Rango A Oficial** (Tribu Zorra Dorada / Segunda Compañera) |
| [`03_inspectora_yumiko.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/03_inspectora_yumiko.md) | **Yumiko** | Alta Elfa | **Auditora Central Rango A Especial** (Grado 1 / Aliada en Deuda de Honor) |
| [`04_maestro_kazuhiko.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/04_maestro_kazuhiko.md) | **Kazuhiko** | Alto Elfo | **Maestro de Gremio Rango S Honorario** (Gobernador de Tsukimi / 320 años) |
| [`05_recepcionista_sora.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/05_recepcionista_sora.md) | **Sora** | Humana | **Recepcionista de Ventanilla Principal & Enlace Exclusiva de Log Horizon** |
| [`06_inspector_daiki.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/06_inspector_daiki.md) | **Daiki** | Elfo Común | **Inspector Evaluador Rango C Senior** (Examinador de Caza y Ascensos) |
| [`07_reclutadora_yumi.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/07_reclutadora_yumi.md) | **Yumi** | Elfa Joven | **Reclutadora de Transporte & Caravanas** (Sección Este del Piso 1) |
| [`08_capitan_ryota.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/08_capitan_ryota.md) | **Ryota** | Humano | **Capitán de Incursión Rango B** (*Colmillo de Hierro* / Vanguardia Kurogane) |
| [`09_maestro_kenzo.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/09_maestro_kenzo.md) | **Kenzo** | Humano Veterano | **Instructor Principal de Esgrima Rango B** (Dojo Colmillo de Hierro) |
| [`10_oficial_kazuma.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/10_oficial_kazuma.md) | **Kazuma** | Humano | **Segundo al Mando Rango B** (*Clan Lanza de Plata* / Aliado de Ruinas) |
| [`11_maestro_herrero_goro.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/11_maestro_herrero_goro.md) | **Goro** | Enano de Kuroishi | **Maestro Armero Superior** (Armería Central y Forjas de Tsukimi) |

---

## 📊 ORGANIGRAMA Y RELACIONES CRUZADAS

* Consulta el documento maestro [`organigrama_y_mapa_politico.md`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/organigrama_y_mapa_politico.md) para la visualización gráfica de líneas de mando y geopolítica interreinos.
* Base de datos JSON automatizada: [`registro_maestro_npcs.json`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/registro_maestro_npcs.json).
* Motor de auditoría y validación activa: [`gestor_base_datos_npcs.py`](file:///home/vola3s/.gemini/antigravity/scratch/LAB_02/base_datos_npcs/gestor_base_datos_npcs.py).

---

## 🔒 BLINDAJES CANÓNICOS Y REGLAS GENTLEMAN 4.0
1. **Cortafuegos Biográfico (Reglas #2.f, #84, #85):** Ningún NPC de esta base de datos puede bajo ningún concepto intuir, deducir o mencionar el Nivel Real 847, los 18 años en la espesura no mapeada, el orfanato Aku o la transmigración de Izanagi.
2. **Nomenclatura Japonesa Estricta (Regla #72):** Todos los nombres de personajes propios son 100% de fonética y origen japonés.
3. **Cero Gamificación (Regla #3):** Los NPCs se expresan en términos de leyes gremiales, grados militares, flujo de maná y estatus social, nunca en términos de interfaz de videojuego.
