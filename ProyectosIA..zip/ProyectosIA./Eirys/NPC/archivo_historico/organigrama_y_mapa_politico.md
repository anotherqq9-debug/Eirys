# 🏛️ ORGANIGRAMA INSTITUCIONAL, FACCIONES Y MAPA POLÍTICO (LAB_02)

---

## 🌲 I. SEDE CENTRAL DEL GREMIO DE AVENTUREROS DE TSUKIMI (REINO ELFO DE SHINRAI)

La administración del Gremio en Tsukimi responde a una jerarquía burocrática y marcial tricentenaria, regida por las leyes del Reino de Shinrai y el Código Continental de Facciones.

```
                         ┌────────────────────────────────────────┐
                         │      MAESTRO DE GREMIO KAZUHIKO        │
                         │ (Alto Elfo / Rango S Honorario / 300a) │
                         └───────────────────┬────────────────────┘
                                             │
                      ┌──────────────────────┴──────────────────────┐
                      ▼                                             ▼
        ┌───────────────────────────┐                 ┌───────────────────────────┐
        │   INSPECCIÓN & AUDITORÍA  │                 │    LOGÍSTICA & RECEPCIÓN   │
        └─────────────┬─────────────┘                 └─────────────┬─────────────┘
                      │                                             │
         ┌────────────┴────────────┐                   ┌────────────┴────────────┐
         ▼                         ▼                   ▼                         ▼
┌─────────────────┐       ┌─────────────────┐ ┌─────────────────┐       ┌─────────────────┐
│ INSPECTORA      │       │ INSPECTOR       │ │ RECEPCIONISTA   │       │ RECLUTADORA     │
│ YUMIKO          │       │ DAIKI           │ │ SORA            │       │ YUMI            │
│ (Rango A Espec.)│       │ (Rango C Senior)│ │ (Ventanilla /   │       │ (Transporte /   │
│ Auditoría Grado1│       │ Evaluador Sede  │ │ Enlace Exclusivo│       │ Escoltas)       │
└─────────────────┘       └─────────────────┘ └─────────────────┘       └─────────────────┘
                                                       │
                                                       ▼
                                              ┌─────────────────┐
                                              │ MAESTRO HERRERO │
                                              │ GORO            │
                                              │ (Armería Central│
                                              │ y Forja Pesada) │
                                              └─────────────────┘
```

---

## ⚔️ II. MAPA DE FACCIONES, CLANES Y SINDICATOS

### 1. 🛡️ FACCIÓN LOG HORIZON (ESTATUS ACTUAL: RANGO C+ INSTITUCIONAL)
* **Líder de Vanguardia:** **Izanagi** (Nivel Real 847 [Secreto Absoluto] / Rango Público C / Placa de Bronce y Hierro Estriado).
* **Primera Compañera & Maga Táctica:** **Aoi** (Mestiza Elfa / Rango C+ Élite / Magia de Carga y Densidad Física).
* **Segunda Compañera & Curadora de Sangre:** **Kohaku** (Demihumana Kitsune / Tribu de la Zorra Dorada / Rango A Oficial).
* **Oficial de Enlace Exclusiva:** **Recepcionista Sora** (Mostrador de Tsukimi).
* **Protección Legal:** Decreto Presidencial de Inviolabilidad (Sello Dorado) y Amparo de Legítima Defensa Asimétrica emitido por el Maestro Kazuhiko.
* **Sigilo Activo:** Sigilo Presidencial Nivel 1 (Terceros desconocen las promociones y la anexión de Kohaku).

### 2. 🐺 CLAN COLMILLO DE HIERRO (*TETSU-NO-KIBA*)
* **Capitán de Incursión y Reclutador Local:** **Capitán Ryota** (Humano / Rango B / Armadura de Placas Pesadas).
* **Instructor de Esgrima y Sables:** **Maestro Kenzo** (Humano / Rango B / Esgrima Pesada).
* **Base Territorial:** Dojo Abierto y Cuartel del Clan Colmillo de Hierro (Zona Alta de Tsukimi).
* **Matriz Superior:** Es la división territorial de choque del **SINDICATO KUROGANE (CLAN DE ACERO)** con sede en la capital real de **Morioka**, comandado por el **Gran Comandante Tatsuya (Rango A+)**.
* **Pacto Actual:** Alianza de Facciones para la Gran Incursión del Nido Alfa en Colina de Piedra (Ventana táctica: 7 días restantes).

### 3. 🗡️ CLAN LANZA DE PLATA (*GIN-NO-YARI*)
* **Segundo al Mando & Oficial de Operaciones:** **Oficial Kazuma** (Rango B / Lancero y Táctico de Ruinas).
* **Relación con Log Horizon:** Aliados en deuda de gratitud y respeto tras la expedición a las Ruinas Subterráneas (Gárgolas de Piedra), donde Izanagi cedió el 50% equitativo del botín.

---

## 🗺️ III. GEOPOLÍTICA INTERREINOS

```
  ┌────────────────────────────────────────────────────────────────────────┐
  │                   REINO ELFO DE SHINRAI (Capital: Morioka)            │
  │  • Ciudad Fronteriza Comercial: Tsukimi (Gobernada por Maestro Kazuhiko)│
  │  • Poderes Militares: Sindicato Kurogane (Comandante Tatsuya)           │
  │  • Cultura: Legalista, aristocracia mágica, alta exigencia burocrática  │
  └───────────────────────────────────┬────────────────────────────────────┘
                                      │
                   [Frontera / Promontorio de Control]
                                      │
  ┌───────────────────────────────────┴────────────────────────────────────┐
  │                 REINO DEMIHUMANO DE SHINZEN (Capital: Kamonome)        │
  │  • Metrópoli Comercial Tercera: Hayama (Sede del clan de Kurokawa)     │
  │  • Estirpe Noble Influyente: Tribu de la Zorra Dorada (Linaje de Kohaku)│
  │  • Cultura: Marcial, devoción a la fuerza del Ápice, honor de linajes   │
  └────────────────────────────────────────────────────────────────────────┘
```

