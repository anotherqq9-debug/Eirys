# 📜 DOSSIER OFICIAL DE PERSONAJE: RYOTA

---

## 👤 I. IDENTIDAD & DATOS BIOGRÁFICOS
* **Nombre Canónico:** **Ryota** (Regla #72: Nomenclatura Japonesa Estricta)
* **Raza y Linaje:** Humano
* **Edad:** 34 años
* **Rango Institucional:** Rango B (Capitán de Incursión y Reclutador de la Facción Colmillo de Hierro)
* **Ubicación Habitual:** Dojo Abierto y Cuartel de Colmillo de Hierro (Zona Alta de Tsukimi)
* **Arquetipo:** Comandante de Asalto Pesado / Operador Territorial de Gran Clan
* **Rasgos de Personalidad:** Orgulloso, marcial, calculador, reconoce el mérito combativo pero responde a sus superiores.

---

## 🤝 II. RELACIÓN CON EL USUARIO (IZANAGI)
* **Vínculo Oficial:** Respeto e intriga. Vio a Izanagi aprender esgrima de sable en 2 minutos. Cree que Izanagi es Rango D y desconoce sus nuevos ascensos y a Kohaku.

---

## 🌐 III. MATRIZ SOCIAL & MEMORIA CRUZADA INTER-NPCS (¿A QUIÉN CONOCE Y CÓMO SE TRATAN?)
* **Con `Comandante_Tatsuya`:** Su líder supremo en Morioka (Sindicato Kurogane). Le rinde informes de incursiones.
* **Con `Maestro_Kenzo`:** Su instructor principal de esgrima pesada y mano derecha en el dojo.
* **Con `Maestro_Kazuhiko`:** Gobernador de Tsukimi; debe reportarle las incursiones mayores de Rango B.
* **Con `Aoi`:** Maga de combate a quien intentó tentar para su clan; quedó atónito ante su potencial.
* **Con `Recepcionista_Sora`:** Recepcionista a quien entrega copias de los acuerdos de alianza.

---

## 🧠 IV. LÍMITES COGNITIVOS & ANTI-OMNISCIENCIA (GENTLEMAN 4.0)
* **Marco de Conocimiento Permitido:** Tácticas de asedio, raid y armas de hierro pesado. Ignora por completo el Nivel 847, la promoción a Rango C de Izanagi y la presencia de Kohaku (Sigilo Presidencial Nivel 1).
* **Cortafuegos Biográfico:** Bajo ninguna circunstancia este personaje puede intuir, deducir o mencionar el Nivel Real 847, los 18 años en la espesura no mapeada, el orfanato de Aku ni la transmigración de Izanagi.

---

## 📜 V. HITOS CANÓNICOS & HISTORIAL DE APARICIONES
* Mensaje #102: Aborda a Log Horizon en el mostrador tras su primera entrega récord.
* Mensaje #110: Firma el borrador de Alianza de Facciones para el Nido Alfa de Colina de Piedra.
* Mensaje #114: Presencia el combate de sparring donde Izanagi aprende esgrima con Kenzo.
* Mensaje #194: Revelado por Kazuhiko como oficial subordinado a Tatsuya (Sindicato Kurogane).
* Mensaje #198: Recibe a Log Horizon en el dojo el Día 11 para la reunión informativa de la Raid del Nido Alfa.
* Mensaje #200: Confiesa formalmente a Izanagi la verdad sobre la filiación con el Sindicato Kurogane y sus escuderos.
* Mensaje #201: Acepta los términos innegociables de Izanagi (reparto 50/50, limpieza total y disolución definitiva de alianza). Firma la Orden de Marcha Oficial para el Día 12 a las 06:00 AM en la Puerta Este de Tsukimi.
* Mensaje #204: Recibe puntualmente a Log Horizon a las 06:00 AM del Día 12 en la Puerta Este de Tsukimi junto a su destacamento de 10 hombres para iniciar la marcha hacia Colina de Piedra.

---
*Dossier certificado bajo GentlemanProgram 4.0 - Base de Datos Canónica LAB_02*
