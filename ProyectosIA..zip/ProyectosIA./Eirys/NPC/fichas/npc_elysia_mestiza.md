# 👤 DOSSIER EXHAUSTIVO DE PERSONAJE NO JUGADOR (NPC)
## Elysia (La Porteadora Silenciosa)

> **Identificador Único:** `elysia_mestiza`  
> **Canon Activo:** Eirys 1.0 • Registro Maestro de Encuentros  
> **Estado Vital:** Vivo  
> **Ubicación Factual Actual:** Camino del Vado Exterior hacia la Puerta Sur de Sayuri  

---

## 1. IDENTIDAD Y PERFIL BIOGRÁFICO
* **Nombre Formal:** Elysia
* **Apodo / Título Común:** La Porteadora Silenciosa
* **Raza / Subespecie Específica:** Mestiza Híbrida (Humano - Elfo de Shinrai)
* **Edad Cronológica y Apariencia:** 19 años (Aparenta 18-19 años)
* **Género:** Femenino
* **Ocupación / Rol Social Primario:** Auxiliar de Porteo / Aprendiz de Magia Gravitatoria
* **Rango Institucional o Gremial:** Sin rango / Porteador Civil de Paso de Kiritōge
* **Nivel Factual de Combate / Peligro:** Rango E • Nivel estimado: 6
* **Origen y Lugar de Nacimiento:** Arrabales de Sayuri (Shinrai)

---

## 2. APARIENCIA FÍSICA Y RASGOS SENSORIALES
* **Estatura y Complexión:** Baja estatura (1.42 m), delgada, hombros marcados por correas de carga, manos ásperas
* **Rasgos Faciales y Marcas Distintivas:** Cabello negro liso hasta la espalda, ojos marrones oscuros expresivos, orejas semipuntiagudas cortas
* **Olor Primario (Firma Olfativa para Izaya):** Aroma tenue a hierba húmeda, sudor limpio, corteza de pino y lino desgastado
* **Voz y Modulación:** Voz suave, clara, ligeramente tímida pero firme al hablar de cuentas y comercio
* **Vestimenta y Equipo Visible:** Sayal rústico de tela de cáñamo remendado en codos, cinturón de soga de lino, botas gastadas
* **Armamento Visible y Oculto:** Bastón de madera nudosa con trozo de cristal translúcido azul-verdoso y vetas púrpuras (foco de maná)

---

## 3. DINÁMICA SOCIAL HACIA IZAYA (SISTEMA BIDIMENSIONAL)
* **Puntuación de Afinidad / Confianza:** `+55` / 100
  * **Categoría Psicológica:** **Aceptación y Respeto Mutuo**
* **Puntuación de Tensión / Hostilidad:** `0` / 100
  * **Estado de Beligerancia:** **Pacífico / Relajado**
* **Primera Impresión Factual sobre Izaya:** Desconcierto total y respeto ante un cazador forastero que la trató como persona y la defendió
* **Interpretación del Aspecto de Izaya:** Lo percibe como un cazador silvestre rústico, humilde y honesto que desconoce la burocracia de Shinrai
* **Condiciones para Ganar su Confianza (+):** Franqueza, trato equitativo, protección mutua y respeto a su trabajo
* **Gatillos de Hostilidad o Ataque (-):** Insultos de sangre mestiza, abuso de poder noble, amenazas físicas

---

## 4. AFILIACIONES, POLÍTICA Y RELIGIÓN
* **Reino de Pertenencia / Lealtad:** Reino Soberano Elfo de Shinrai (Ciudadana de segunda clase por mestizaje)
* **Facción / Clan / Gremio:** Gremio de Porteadores y Auxiliares del Paso de Kiritōge
* **Postura Política Factual:** Resignación pragmática frente al desprecio noble; búsqueda de independencia económica
* **Creencia Religiosa / Filosófica:** Respeto al ciclo de la naturaleza y espíritus del bosque
* **Prejuicios Raciales o Culturales:** Cautela instintiva frente a nobles de túnica fina; afinidad natural con otros marginados

---

## 5. RED DE VÍNCULOS Y RELACIONES CON OTROS NPCS
* **Ifrid:** Ex-contratista aristócrata — Noble arrogante que la contrató como mula de carga verbalmente y la maltrató hasta la ruptura

---

## 6. LÍMITES COGNITIVOS Y CORTAFUEGOS ANTI-OMNISCIENCIA (GENTLEMANPROGRAM 4.2)
* **Lo que este NPC SÍ sabe:**
  - Rutas comerciales y aduaneras entre Kiritōge y la Ciudadela de Sayuri
  - Tarifas de mercado de carne seca, provisiones y comisiones de escribanos en Sayuri
  - Magia básica de alteración de peso (gravedad comprimida aplicada a bultos)
  - Izaya es un cazador forastero de Mizuhara que viaja solo y carece de dinero en efectivo
* **Lo que este NPC TIENE PROHIBIDO SABER (Cortafuegos):**
  - El pasado de Izaya en el orfanato Alkesta o la masacre de hace 18 años
  - La existencia, fauna o supervivencia en el corazón de Kurokura Jukai
  - El nivel real de combate o capacidades biomecánicas Apex de Izaya
  - Los dos cuchillos de Izaya son colmillos de la Calamidad de Kisara
* **Léxico y Expresiones Prohibidas para su Voz:**
  - kurokura
  - bosque profundo
  - zona no mapeada
  - depredador apex
  - nivel 97
  - stats
  - hp

---

## 7. HISTORIAL FACTUAL DE INTERACCIONES CON IZAYA
* **[Día 10 • 12:35 PM]:** Izaya le pregunta si está bien y le regala una pera madura ignorando las burlas nobles. (Impacto: Afinidad +20 | Hostilidad +0)
* **[Día 10 • 12:47 PM]:** Izaya le ofrece ser su guía tras tasar la cecina y la respalda para soltar la carga de Ifrid. (Impacto: Afinidad +25 | Hostilidad +0)
* **[Día 10 • 12:52 PM]:** Izaya frena la agresión de Ifrid con un grito teatral a la guardia y la protege de falsas acusaciones. (Impacto: Afinidad +10 | Hostilidad +0)
