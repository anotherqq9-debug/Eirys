"""
Módulo de Gestión Automatizada y Registro Exhaustivo de NPCs (Eirys 1.0)
Función: registrar_nuevo_npc() / actualizar_estado_npc()

Genera y mantiene fichas individuales detalladas en formato Markdown dentro de:
  Eirys/NPC/fichas/npc_[id].md
y sincroniza el registro maestro estructurado en:
  Eirys/NPC/registro_maestro_npcs.json
junto con la matriz social en:
  Eirys/Red Social/matriz_relaciones_sociales.json

SISTEMA SOCIAL BIDIMENSIONAL (Afinidad & Tensión Hostil):
- Afinidad / Confianza (-100 a +100):
    * -100 a -60: Desprecio Absoluto / Asco
    * -59 a -20:  Desconfianza / Frialdad
    * -19 a +19:  Neutralidad / Indiferencia
    * +20 a +59:  Aceptación / Respeto
    * +60 a +89:  Confianza de Camarada
    * +90 a +100: Lealtad Absoluta / Miembro de Manada
- Nivel de Beligerancia / Hostilidad (0 a 100):
    * 0 a 19:   Pacífico / Desarmado
    * 20 a 49:  Alerta / Precavido
    * 50 a 74:  Tenso / Agresivo Latente
    * 75 a 89:  Hostil Abierto / Provocador
    * 90 a 100: Asesino / Letal Inmediato
"""

import os
import sys
import json
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
NPC_DIR = os.path.join(BASE_DIR, "NPC")
FICHAS_DIR = os.path.join(NPC_DIR, "fichas")
MAESTRO_JSON = os.path.join(NPC_DIR, "registro_maestro_npcs.json")
MATRIZ_JSON = os.path.join(BASE_DIR, "Red Social", "matriz_relaciones_sociales.json")

def clasificar_estado_social(afinidad, hostilidad):
    """Calcula la etiqueta psicológica y dinámica de comportamiento del NPC hacia Izaya."""
    # Etiqueta de afinidad
    if afinidad <= -60:
        etiq_afinidad = "Desprecio y Repulsión"
    elif afinidad <= -20:
        etiq_afinidad = "Desconfianza y Frialdad"
    elif afinidad <= 19:
        etiq_afinidad = "Neutralidad Cautelosa"
    elif afinidad <= 59:
        etiq_afinidad = "Aceptación y Respeto Mutuo"
    elif afinidad <= 89:
        etiq_afinidad = "Confianza de Camarada"
    else:
        etiq_afinidad = "Lealtad Absoluta / Manada Territorial"

    # Etiqueta de hostilidad
    if hostilidad <= 19:
        etiq_hostilidad = "Pacífico / Relajado"
    elif hostilidad <= 49:
        etiq_hostilidad = "Alerta / En Guardia"
    elif hostilidad <= 74:
        etiq_hostilidad = "Tenso / Mano en el Arma"
    elif hostilidad <= 89:
        etiq_hostilidad = "Hostilidad Abierta / Agresión Verbal o Táctica"
    else:
        etiq_hostilidad = "Ataque Inminente / Instinto Asesino Desatado"

    return etiq_afinidad, etiq_hostilidad

def generar_ficha_markdown(npc_data):
    """Crea una ficha exhaustiva, sin abreviaciones ni resúmenes superficiales."""
    af = npc_data.get("afinidad_izaya", 0)
    ho = npc_data.get("hostilidad_izaya", 0)
    e_af, e_ho = clasificar_estado_social(af, ho)

    md = f"""# 👤 DOSSIER EXHAUSTIVO DE PERSONAJE NO JUGADOR (NPC)
## {npc_data.get('nombre_completo', 'Desconocido')} {f"({npc_data.get('apodo', '')})" if npc_data.get('apodo') else ""}

> **Identificador Único:** `{npc_data.get('id')}`  
> **Canon Activo:** Eirys 1.0 • Registro Maestro de Encuentros  
> **Estado Vital:** {npc_data.get('estado_vital', 'Vivo')}  
> **Ubicación Factual Actual:** {npc_data.get('ubicacion_actual', 'No definida')}  

---

## 1. IDENTIDAD Y PERFIL BIOGRÁFICO
* **Nombre Formal:** {npc_data.get('nombre_completo', 'Desconocido')}
* **Apodo / Título Común:** {npc_data.get('apodo', 'Ninguno')}
* **Raza / Subespecie Específica:** {npc_data.get('raza_y_linaje', 'Humano')}
* **Edad Cronológica y Apariencia:** {npc_data.get('edad', 'Desconocida')} años (Aparenta {npc_data.get('apariencia_edad', 'acorde')})
* **Género:** {npc_data.get('genero', 'No especificado')}
* **Ocupación / Rol Social Primario:** {npc_data.get('ocupacion_y_cargo', 'Campesino / Civil')}
* **Rango Institucional o Gremial:** {npc_data.get('rango_institucional', 'Sin rango / Civil común')}
* **Nivel Factual de Combate / Peligro:** Rango {npc_data.get('rango_peligro', 'E')} • Nivel estimado: {npc_data.get('nivel_estimado', 5)}
* **Origen y Lugar de Nacimiento:** {npc_data.get('lugar_nacimiento', 'Desconocido')}

---

## 2. APARIENCIA FÍSICA Y RASGOS SENSORIALES
* **Estatura y Complexión:** {npc_data.get('complexion_y_estatura', 'Estatura media, complexión estándar')}
* **Rasgos Faciales y Marcas Distintivas:** {npc_data.get('rasgos_faciales', 'Sin cicatrices ni rasgos destacados')}
* **Olor Primario (Firma Olfativa para Izaya):** {npc_data.get('aroma_olfativo', 'Olor a sudor seco, tela vieja y tierra')}
* **Voz y Modulación:** {npc_data.get('voz_y_timbre', 'Tono pausado, volumen medio')}
* **Vestimenta y Equipo Visible:** {npc_data.get('vestimenta_detallada', 'Ropa rústica de trabajo')}
* **Armamento Visible y Oculto:** {npc_data.get('armamento', 'Cuchillo de corte en cinto')}

---

## 3. DINÁMICA SOCIAL HACIA IZAYA (SISTEMA BIDIMENSIONAL)
* **Puntuación de Afinidad / Confianza:** `{af:+d}` / 100
  * **Categoría Psicológica:** **{e_af}**
* **Puntuación de Tensión / Hostilidad:** `{ho}` / 100
  * **Estado de Beligerancia:** **{e_ho}**
* **Primera Impresión Factual sobre Izaya:** {npc_data.get('primera_impresion', 'Indiferente')}
* **Interpretación del Aspecto de Izaya:** {npc_data.get('percepcion_aspecto_izaya', 'Lo ve como un vagabundo o cazador silvestre inofensivo')}
* **Condiciones para Ganar su Confianza (+):** {npc_data.get('gatillos_confianza', 'Trato directo, respeto a sus costumbres')}
* **Gatillos de Hostilidad o Ataque (-):** {npc_data.get('gatillos_hostilidad', 'Amenazas, armas desenfundadas o engaños')}

---

## 4. AFILIACIONES, POLÍTICA Y RELIGIÓN
* **Reino de Pertenencia / Lealtad:** {npc_data.get('reino_afiliacion', 'Neutral')}
* **Facción / Clan / Gremio:** {npc_data.get('faccion_o_clan', 'Independiente')}
* **Postura Política Factual:** {npc_data.get('postura_politica', 'Sumisión pragmática a la autoridad local')}
* **Creencia Religiosa / Filosófica:** {npc_data.get('religion_y_fe', 'Sintoísmo animista local')}
* **Prejuicios Raciales o Culturales:** {npc_data.get('prejuicios', 'Desconfianza natural hacia forasteros')}

---

## 5. RED DE VÍNCULOS Y RELACIONES CON OTROS NPCS
{format_relaciones_markdown(npc_data.get('relaciones_con_otros', []))}

---

## 6. LÍMITES COGNITIVOS Y CORTAFUEGOS ANTI-OMNISCIENCIA (GENTLEMANPROGRAM 4.2)
* **Lo que este NPC SÍ sabe:**
{format_lista_markdown(npc_data.get('conocimientos_permitidos', ['Conoce su aldea y su oficio inmediato']))}
* **Lo que este NPC TIENE PROHIBIDO SABER (Cortafuegos):**
{format_lista_markdown(npc_data.get('conocimientos_prohibidos', ['El pasado de Izaya', 'El poder real o nivel 97 de Izaya', 'Eventos fuera de su rango visual']))}
* **Léxico y Expresiones Prohibidas para su Voz:**
{format_lista_markdown(npc_data.get('terminos_prohibidos', ['Términos de videojuego', 'Rango de maná numérico', 'HP / Stats']))}

---

## 7. HISTORIAL FACTUAL DE INTERACCIONES CON IZAYA
{format_historial_interacciones(npc_data.get('historial_interacciones', []))}
"""
    return md

def format_lista_markdown(lista):
    if not lista:
        return "  - Ninguno registrado."
    return "\n".join([f"  - {elem}" for elem in lista])

def format_relaciones_markdown(relaciones):
    if not relaciones:
        return "* *Sin relaciones secundarias indexadas aún.*"
    salida = []
    for r in relaciones:
        salida.append(f"* **{r.get('npc_relacionado', 'NPC')}:** {r.get('tipo_vinculo', 'Conocido')} — {r.get('descripcion', '')}")
    return "\n".join(salida)

def format_historial_interacciones(historial):
    if not historial:
        return "* *Encuentro inicial pendiente de desarrollo narrativo.*"
    salida = []
    for h in historial:
        salida.append(f"* **[{h.get('marca_tiempo', 'Día 1')}]:** {h.get('resumen_factual', '')} (Impacto: Afinidad {h.get('delta_afinidad', 0):+d} | Hostilidad {h.get('delta_hostilidad', 0):+d})")
    return "\n".join(salida)

def registrar_o_actualizar_npc(datos_npc):
    """
    Registra un nuevo NPC o actualiza uno existente:
    1. Escribe la ficha exhaustiva en Markdown dentro de NPC/fichas/npc_[id].md
    2. Actualiza el JSON maestro de NPCs (registro_maestro_npcs.json)
    3. Sincroniza la matriz social (matriz_relaciones_sociales.json)
    """
    os.makedirs(FICHAS_DIR, exist_ok=True)
    npc_id = datos_npc.get("id")
    if not npc_id:
        print("Error: El NPC requiere un 'id' único (ej: 'shugo_nobunaga', 'curandera_matsuri').")
        return False

    # 1. Crear / Sobrescribir ficha en Markdown
    ficha_path = os.path.join(FICHAS_DIR, f"npc_{npc_id}.md")
    contenido_md = generar_ficha_markdown(datos_npc)
    with open(ficha_path, 'w', encoding='utf-8') as f:
        f.write(contenido_md)

    # 2. Actualizar registro maestro JSON
    maestro = {"_descripcion": "Registro maestro de NPCs activos para la nueva narrativa de Eirys (Punto Cero).", "npcs_activos": {}}
    if os.path.exists(MAESTRO_JSON):
        try:
            with open(MAESTRO_JSON, 'r', encoding='utf-8') as f:
                maestro = json.load(f)
        except Exception:
            pass

    maestro.setdefault("npcs_activos", {})[npc_id] = {
        "id": npc_id,
        "nombre": datos_npc.get("nombre_completo"),
        "apodo": datos_npc.get("apodo", ""),
        "raza": datos_npc.get("raza_y_linaje"),
        "ocupacion": datos_npc.get("ocupacion_y_cargo"),
        "reino": datos_npc.get("reino_afiliacion"),
        "afinidad": datos_npc.get("afinidad_izaya", 0),
        "hostilidad": datos_npc.get("hostilidad_izaya", 0),
        "estado_vital": datos_npc.get("estado_vital", "Vivo"),
        "ficha_md": f"NPC/fichas/npc_{npc_id}.md",
        "ultima_actualizacion": datetime.now().isoformat()
    }

    with open(MAESTRO_JSON, 'w', encoding='utf-8') as f:
        json.dump(maestro, f, indent=2, ensure_ascii=False)

    # 3. Sincronizar Matriz Social JSON
    matriz = {"_descripcion": "Matriz de lealtades, afinidad y relaciones sociales de Eirys.", "facciones": {}, "relaciones_individuales": {}}
    if os.path.exists(MATRIZ_JSON):
        try:
            with open(MATRIZ_JSON, 'r', encoding='utf-8') as f:
                matriz = json.load(f)
        except Exception:
            pass

    e_af, e_ho = clasificar_estado_social(datos_npc.get("afinidad_izaya", 0), datos_npc.get("hostilidad_izaya", 0))
    matriz.setdefault("relaciones_individuales", {})[npc_id] = {
        "nombre": datos_npc.get("nombre_completo"),
        "afinidad": datos_npc.get("afinidad_izaya", 0),
        "hostilidad": datos_npc.get("hostilidad_izaya", 0),
        "estado_afinidad": e_af,
        "estado_hostilidad": e_ho,
        "faccion": datos_npc.get("faccion_o_clan", "Independiente"),
        "vinculos_secundarios": datos_npc.get("relaciones_con_otros", [])
    }

    with open(MATRIZ_JSON, 'w', encoding='utf-8') as f:
        json.dump(matriz, f, indent=2, ensure_ascii=False)

    print(f"✓ NPC '{datos_npc.get('nombre_completo')}' registrado exhaustivamente en '{ficha_path}' y sincronizado.")
    return True

if __name__ == "__main__":
    print("[MÓDULO GESTOR DE NPCS]: Inicializado y listo.")
