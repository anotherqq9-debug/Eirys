# 👥 MÓDULO DE PERSONAJES NO JUGADORES (NPCS) (EIRYS)

---

## 🎯 PROPÓSITO
Garantiza la **coherencia nominativa, jerárquica y los límites cognitivos individuales** de cada personaje.
Cada NPC posee su propia ficha con su lista de términos prohibidos para evitar omnisciencia y mantener su voz canónica.

## 📁 ARCHIVOS
* `registro_maestro_npcs.json`: Directorio unificado de NPCs con sus roles y restricciones cognitivas.
* `/fichas/`: Fichas individuales detalladas en Markdown de cada personaje.
