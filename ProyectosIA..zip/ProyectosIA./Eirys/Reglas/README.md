# ⚖️ MÓDULO DE REGLAS MAESTRAS Y GUARDRAILS (EIRYS)

---

## 🎯 PROPÓSITO
Alberga las **leyes fundamentales e inmutables** que rigen la simulación de la realidad.
Son las directrices que impiden bugs narrativos, pérdida de agencia del usuario, retcons y gamificación artificial.

## 📁 ARCHIVOS
* `compendio_reglas_maestras.md`: Texto completo, exhaustivo y desglosado de todas las reglas del sistema.
* `guardrails_sistema.json`: Diccionario formal de restricciones y códigos de intercepción automática.
