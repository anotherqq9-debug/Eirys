# 🏞️ MÓDULO DE ESCENARIO Y ENTORNO (EIRYS)

---

## 🎯 PROPÓSITO
Este módulo define y gestiona el **entorno físico, bioma activo, visibilidad, condiciones climáticas y estructuras** presentes en la escena actual.
Garantiza que la narrativa respete la física del terreno, la acústica, la propagación de luz y los límites espaciales.

## 📁 ARCHIVOS
* `estado_escenario.json`: Parámetros en tiempo real del bioma, clima, terreno y visibilidad.
* `panel_escenario.html`: Visor gráfico interactivo del teatro de operaciones.
