"""
Módulo del Sistema: GentlemanProgram - Motor de Auditoría Factual y Multicapa (Eirys Punto Cero)
Versión: 4.2 (14 Engranajes Factuales de Verificación + Motor Epistémico Desacoplado)
"""

import os
import json
import re

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
RULES_FILE = os.path.join(BASE_DIR, "Reglas", "compendio_reglas_maestras.md")
INVENTORY_FILE = os.path.join(BASE_DIR, "Inventario", "estado_inventario.json")
NPC_FILE = os.path.join(BASE_DIR, "NPC", "registro_maestro_npcs.json")
CANON_FILE = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Positivo", "registro_canon_admitido.json")
ERRORS_DIR = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Negativo")
PERSONAJE_FILE = os.path.join(BASE_DIR, "Personaje", "ficha_personaje_usuario.md")

os.makedirs(ERRORS_DIR, exist_ok=True)

class ValidatorNarrativoGentleman:
    def __init__(self):
        self.rules_path = RULES_FILE
        self.errors_log = os.path.join(ERRORS_DIR, "registro_errores_y_soluciones.json")

    def validar_respuesta(self, texto_respuesta):
        fallas = []
        texto_lower = texto_respuesta.lower()

        # 1. MOTOR DE ENCABEZADO ESTRICTO
        header_pattern = r"\[CAPÍTULO \d+ \| PARTE \d+ \| MENSAJE #?\d+\]\s*\n📍 UBICACIÓN:.+\s*\n⏳ TIEMPO:.+\s*\n📌 ESTADO:.+\s*\n🔒 CANON ACTIVO:.+"
        # Formato alternativo flexible que incluya estado de acompañante o protagonista
        header_pattern_alt = r"\[CAPÍTULO \d+ \| PARTE \d+ \| MENSAJE #?\d+\]\s*\n📍 UBICACIÓN:.+\s*\n⏳ TIEMPO:.+"
        if not (re.search(header_pattern, texto_respuesta.strip()) or re.search(header_pattern_alt, texto_respuesta.strip())):
            fallas.append({
                "motor": "HEADER",
                "codigo": "ERR_HEADER_MISSING",
                "descripcion": "Falta el encabezado estricto de metadatos o formato no conforme."
            })

        # 2. MOTOR DE AGENCIA DEL PROTAGONISTA (Cero asunción de pensamientos o emociones)
        frases_control = [
            "pensaste que", "decidiste que", "te sentiste asustado de", 
            "tuviste miedo de", "sentiste que debías", "te diste cuenta de que querías"
        ]
        for frase in frases_control:
            if frase in texto_lower:
                fallas.append({
                    "motor": "AGENCIA_USUARIO",
                    "codigo": "ERR_USER_AGENCY",
                    "descripcion": f"Se asumió un pensamiento, sentimiento o decisión interna del usuario: '{frase}'."
                })

        # 3. MOTOR DE LÉXICO PROHIBIDO DE METAGAMING / RPG (Cero Gamificación en Diálogos y Narración)
        terminos_metagaming = [
            "barra de vida", "puntos de experiencia", "stats", "pantalla de estado", 
            "skill tree", "subir de nivel", "hit points", "puntos de maná"
        ]
        for term_meta in terminos_metagaming:
            if re.search(rf"\b{term_meta}\b", texto_lower):
                fallas.append({
                    "motor": "METAGAMING_RPG",
                    "codigo": "ERR_RPG_METAGAMING_LEXICON",
                    "descripcion": f"Violación de Inmersión (Cero Gamificación): Se utilizó el término de videojuego '{term_meta}'."
                })

        # 4. MOTOR COGNITIVO NPC (Anti-Omnisciencia & Límites de NPCs registrados)
        texto_narrativa_pura = texto_respuesta
        if "[SISTEMA / NARRATIVA]:" in texto_respuesta:
            texto_narrativa_pura = texto_respuesta.split("[SISTEMA / NARRATIVA]:", 1)[1]
        elif "[SISTEMA]:" in texto_respuesta:
            texto_narrativa_pura = texto_respuesta.split("[SISTEMA]:", 1)[1]

        lineas_narrativa = [
            l for l in texto_narrativa_pura.split('\n') 
            if not any(l.strip().startswith(p) for p in ["[CAPÍTULO", "📍", "⏳", "📌", "🔒", "### 📝", "### 📊"])
        ]
        cuerpo_narrativo_lower = "\n".join(lineas_narrativa).lower()

        if os.path.exists(NPC_FILE):
            try:
                with open(NPC_FILE, 'r', encoding='utf-8') as f:
                    data_raw = json.load(f)
                    npcs_data = data_raw.get("npcs_activos", data_raw)
                    
                for npc_id, npc_info in npcs_data.items():
                    if not isinstance(npc_info, dict):
                        continue
                    nombre_real = npc_info.get("nombre", npc_id)
                    prohibidos = npc_info.get("terminos_prohibidos", [])
                    
                    for term in prohibidos:
                        pattern_npc = rf"\b{nombre_real.lower()}\b[^.!?\n]{{0,100}}(?<!anti-)\b{term}\b"
                        if re.search(pattern_npc, cuerpo_narrativo_lower):
                            fallas.append({
                                "motor": "COGNITIVO_NPC",
                                "codigo": "ERR_NPC_OMNISCIENCE",
                                "descripcion": f"El NPC '{nombre_real}' utilizó o razonó sobre el término prohibido '{term}'."
                            })
            except Exception:
                pass

        # 5. MOTOR DE CORTAFUEGOS DE PRIVACIDAD DEL PROTAGONISTA
        # Previene que NPCs revelen secretos no confesados
        dialogos_npc = re.findall(r"—\s*[\*\"«]?(.*?)[\*\"»]?\s*—", texto_respuesta)
        # Si la ficha de personaje existe, se pueden extraer secretos
        if os.path.exists(PERSONAJE_FILE):
            try:
                with open(PERSONAJE_FILE, 'r', encoding='utf-8') as f:
                    p_content = f.read().lower()
                    # Si contiene secretos explícitos delimitados
                    m_sec = re.findall(r"secreto:\s*(.+)", p_content)
                    for sec in m_sec:
                        sec_str = sec.strip()
                        if len(sec_str) > 3:
                            for dial in dialogos_npc:
                                if sec_str in dial.lower():
                                    fallas.append({
                                        "motor": "CORTAFUEGOS_PRIVACIDAD",
                                        "codigo": "ERR_PRIVACY_LEAK_NPC",
                                        "descripcion": f"Falla Crítica de Privacidad: Un NPC reveló el secreto no divulgado '{sec_str}'."
                                    })
            except Exception:
                pass

        # 6. MOTOR DE COHERENCIA EPISTÉMICA Y CANON ADMITIDO
        if os.path.exists(CANON_FILE):
            try:
                with open(CANON_FILE, 'r', encoding='utf-8') as f:
                    canon_data = json.load(f)
                
                hechos = canon_data.get("hechos_canonicos", [])
                for h in hechos:
                    patrones = h.get("patrones_violacion_regex", [])
                    for pat in patrones:
                        if re.search(pat, cuerpo_narrativo_lower):
                            fallas.append({
                                "motor": "EPISTEMICO_FACTUAL",
                                "codigo": f"ERR_FACTUAL_CONTRADICTION_{h.get('id', 'HECHO')}",
                                "descripcion": h.get("mensaje_error", "Contradicción con hecho canónico admitido")
                            })
            except Exception:
                pass

        # 7. MOTOR DE INERCIA INSTITUCIONAL Y CAUTELA BUROCRÁTICA
        # Previene que gremios, guardias o nobles otorguen simpatía o adulación inmediata
        adulaciones_inmediatas = [
            "eres increíble", "confío plenamente en ti", "el gremio te agradece eternamente",
            "asombroso cazador", "un talento prodigioso", "sin duda eres un héroe"
        ]
        for adul in adulaciones_inmediatas:
            if adul in cuerpo_narrativo_lower:
                fallas.append({
                    "motor": "INERCIA_INSTITUCIONAL",
                    "codigo": "ERR_INSTITUTIONAL_ADULATION",
                    "descripcion": f"Violación de Inercia Institucional: Se detectó validación o confianza prematura no justificada ('{adul}')."
                })

        deducciones_absurdas = [
            "sobrevivió en el bosque prohibido", "viene de kurokura jukai", 
            "es un espía imperial encubierto", "sobreviviente del bosque primordial"
        ]
        for deduc in deducciones_absurdas:
            if deduc in cuerpo_narrativo_lower:
                fallas.append({
                    "motor": "DESCONEXION_EPISTEMICA_OCKHAM",
                    "codigo": "ERR_ABSURD_NPC_DEDUCTION",
                    "descripcion": f"Violación de la Navaja de Ockham: Un NPC dedujo un hecho considerado imposible para la sociedad ('{deduc}')."
                })

        # 9. MOTOR DE AISLAMIENTO EPISTÉMICO DE KUROKURA Y TERRITORIOS PROHIBIDOS (ANTI-CONTAMINACIÓN AMBIENTAL)
        # Impide que NPCs o diálogos traten a Kurokura Jukai, sus monstruos o el 'bosque profundo' como lugares conocidos o accesibles
        terminos_zona_muerte = [
            "bosque profundo", "kurokura jukai", "kurokura", "gran alcanfor",
            "alcanforero centenario", "zona no mapeada", "bosque prohibido", "selva central"
        ]
        
        # Analizar todos los diálogos de NPCs
        for dial in dialogos_npc:
            d_low = dial.lower()
            for t_zm in terminos_zona_muerte:
                if re.search(rf"\b{t_zm}\b", d_low):
                    fallas.append({
                        "motor": "AISLAMIENTO_EPISTEMICO_KUROKURA",
                        "codigo": "ERR_NPC_KUROKURA_LEAK",
                        "descripcion": f"Fuga Epistémica de Zona de Exclusión: Un NPC mencionó o hizo alusión al territorio no mapeado/prohibido ('{t_zm}')."
                    })

        valido = len(fallas) == 0
        return valido, fallas

if __name__ == "__main__":
    v = ValidatorNarrativoGentleman()
    print("[DETECTOR GENTLEMAN 4.2]: Motor cargado e inicializado en Eirys.")
