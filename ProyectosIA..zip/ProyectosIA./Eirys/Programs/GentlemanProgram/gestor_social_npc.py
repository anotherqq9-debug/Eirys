"""
Módulo del Sistema: GentlemanProgram - Gestor de Perfiles Sociales, Psicología y Red de Contactos NPC
Eirys 1.0 (Punto Cero)
"""

import os
import json

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
NPC_DATABASE = os.path.join(BASE_DIR, "NPC", "registro_maestro_npcs.json")
SOCIAL_MATRIX = os.path.join(BASE_DIR, "Red Social", "matriz_relaciones_sociales.json")

class GestorSocialNPC:
    def __init__(self):
        self.db_path = NPC_DATABASE
        self.matrix_path = SOCIAL_MATRIX
        self.data = self._cargar_db()

    def _cargar_db(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    content = json.load(f)
                    return content.get("npcs_activos", {})
            except Exception:
                return {}
        return {}

    def _guardar_db(self):
        contenedor = {
            "_descripcion": "Registro maestro de NPCs activos para la nueva narrativa de Eirys (Punto Cero).",
            "npcs_activos": self.data
        }
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(contenedor, f, indent=2, ensure_ascii=False)

    def registrar_o_cargar_npc(self, nombre_npc, arquetipo="Civil", rasgo_dominante="Neutral", prejuicio_base=50):
        if nombre_npc not in self.data:
            self.data[nombre_npc] = {
                "nombre": nombre_npc,
                "personalidad_base": {
                    "arquetipo": arquetipo,
                    "rasgo_dominante": rasgo_dominante,
                    "prejuicio_hacia_desconocidos": prejuicio_base
                },
                "escala_relacion_usuario": {
                    "confianza": 0,          # -100 a +100
                    "suspicacia": 50,        # 0 a 100
                    "respeto": 0,            # -100 a +100
                    "afinidad_emocional": 0, # -100 a +100
                    "temor": 0               # 0 a 100
                },
                "terminos_prohibidos": [],
                "red_de_contactos_npc": [],
                "observaciones_y_memoria": []
            }
            self._guardar_db()
            print(f"[MATRIZ SOCIAL NPC]: Registrado NPC '{nombre_npc}' en Eirys (Punto Cero).")
        return self.data[nombre_npc]

    def actualizar_relacion_usuario(self, nombre_npc, delta_confianza=0, delta_suspicacia=0, delta_respeto=0, delta_afinidad=0, delta_temor=0, observacion=""):
        if nombre_npc in self.data:
            rel = self.data[nombre_npc]["escala_relacion_usuario"]
            rel["confianza"] = max(-100, min(100, rel["confianza"] + delta_confianza))
            rel["suspicacia"] = max(0, min(100, rel["suspicacia"] + delta_suspicacia))
            rel["respeto"] = max(-100, min(100, rel["respeto"] + delta_respeto))
            rel["afinidad_emocional"] = max(-100, min(100, rel["afinidad_emocional"] + delta_afinidad))
            rel["temor"] = max(0, min(100, rel["temor"] + delta_temor))
            if observacion:
                self.data[nombre_npc]["observaciones_y_memoria"].append(observacion)
            self._guardar_db()
            return True
        return False

if __name__ == "__main__":
    g = GestorSocialNPC()
    print(f"[GESTOR SOCIAL NPC]: Sistema activo en Eirys. NPCs registrados: {len(g.data)}")
