"""
Auditor Epistémico y de Coherencia Narrativa Multicapa (LAB 02)
GentlemanProgram 4.0 - Engine 10 & 11 Automated Cross-Verification
"""

import os
import json
import re

LAB_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
STATE_FILE = os.path.join(LAB_DIR, "mopaly_system", "estado_usuario.json")
NPC_FILE = os.path.join(LAB_DIR, "mopaly_system", "matriz_social_npcs.json")
EPISTEMIC_FILE = os.path.join(LAB_DIR, "mopaly_system", "matriz_epistemica_factual.json")
HISTORY_FILE = os.path.join(LAB_DIR, "mopaly_system", "mopaly_history_full.txt")

def auditar_todo_el_sistema():
    print("=== AUDITORÍA EPISTÉMICA Y FACTUAL (GENTLEMAN 4.0) ===")
    reporte = {
        "estado_archivos": {},
        "hechos_verificados": 0,
        "anomalías_detectadas": [],
        "integridad_canon": True
    }

    # 1. Verificación de Existencia de Archivos Críticos
    archivos = {
        "estado_usuario": STATE_FILE,
        "matriz_social_npcs": NPC_FILE,
        "matriz_epistemica": EPISTEMIC_FILE,
        "historial_full": HISTORY_FILE
    }
    for nombre, path in archivos.items():
        existe = os.path.exists(path)
        reporte["estado_archivos"][nombre] = "OK" if existe else "FALTANTE"
        if not existe:
            reporte["anomalías_detectadas"].append(f"Archivo crítico no encontrado: {path}")
            reporte["integridad_canon"] = False

    if not reporte["integridad_canon"]:
        return reporte

    # 2. Cargar Datos
    with open(STATE_FILE, 'r', encoding='utf-8') as f:
        st = json.load(f)
    with open(NPC_FILE, 'r', encoding='utf-8') as f:
        npcs = json.load(f)
    with open(EPISTEMIC_FILE, 'r', encoding='utf-8') as f:
        epistemic = json.load(f)
    with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
        history_text = f.read()

    # 3. Auditoría de Hechos Certificados contra el Historial Reciente
    hechos = epistemic.get("hechos_certificados", [])
    reporte["hechos_verificados"] = len(hechos)
    
    # Revisar los últimos 15,000 caracteres de historial (intercambios recientes)
    historial_reciente = history_text[-15000:].lower()

    for h in hechos:
        h_id = h.get("id")
        patrones = h.get("patrones_violacion_regex", [])
        for pat in patrones:
            m = re.search(pat, historial_reciente)
            if m:
                reporte["anomalías_detectadas"].append({
                    "hecho_id": h_id,
                    "error": h.get("mensaje_error"),
                    "fragmento": m.group(0)
                })
                reporte["integridad_canon"] = False

    # 4. Auditoría de Coherencia de Yumiko en Matriz Social
    if "Yumiko" not in npcs:
        reporte["anomalías_detectadas"].append("Yumiko no está registrada en matriz_social_npcs.json")
        reporte["integridad_canon"] = False
    else:
        yumiko_data = npcs["Yumiko"]
        yumiko_mems = " ".join(yumiko_data.get("observaciones_y_memoria", [])).lower()
        if "kohaku" not in yumiko_mems:
            reporte["anomalías_detectadas"].append("La memoria de Yumiko no registra la incorporación de Kohaku")
            reporte["integridad_canon"] = False

    # 5. Auditoría de Ubicación y Salud en estado_usuario.json
    p = st.get("personaje", {})
    ubicacion = p.get("ubicacion_actual", {}).get("punto_especifico", "")
    puntos_canonicos = ["Hayama", "Tsukimi", "Sendero", "Desfiladero", "Frontera", "Colina de Piedra", "Garganta", "Caldera"]
    if not any(loc in ubicacion for loc in puntos_canonicos):
        reporte["anomalías_detectadas"].append(f"Ubicación en estado_usuario.json discordante: {ubicacion}")
        reporte["integridad_canon"] = False

    # 6. Conclusión
    print(f"✓ Hechos Epistémicos Inmutables Auditados: {reporte['hechos_verificados']}")
    print(f"✓ NPCs con Ficha y Matriz Social Auditados: {len(npcs)}")
    print(f"✓ Estado de Integridad del Canon: {'100% LIMPIO / CERTIFICADO' if reporte['integridad_canon'] else 'CON ANOMALÍAS'}")
    if reporte["anomalías_detectadas"]:
        print("⚠️ ANOMALÍAS:")
        for a in reporte["anomalías_detectadas"]:
            print(f"  - {a}")
    else:
        print("✓ Cero contradicciones detectadas en la cronología reciente.")

    return reporte

if __name__ == "__main__":
    auditar_todo_el_sistema()
