import os
import sys
BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import json
import re

BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
STATE_JSON = os.path.join(BASE_DIR, "mopaly_system", "estado_usuario.json")
PANEL_HTML = os.path.join(BASE_DIR, "Main", "escenario", "panel_estado.html")

def cargar_estado():
    if not os.path.exists(STATE_JSON):
        raise FileNotFoundError(f"No existe estado_usuario.json en {STATE_JSON}")
    with open(STATE_JSON, 'r', encoding='utf-8') as f:
        return json.load(f)

def guardar_estado(estado_data):
    with open(STATE_JSON, 'w', encoding='utf-8') as f:
        json.dump(estado_data, f, indent=2, ensure_ascii=False)
    actualizar_panel_html(estado_data)
    try:
        from mopaly_system.generador_panel_ui import generar_y_sincronizar_panel
        generar_y_sincronizar_panel()
    except Exception as e:
        print(f"Error sincronizando panel UI: {e}")

def actualizar_panel_html(estado_data):
    if not os.path.exists(PANEL_HTML):
        return

    p = estado_data.get("personaje", {})
    monedas = p.get("monedas", {"oro": 0, "plata": 0, "cobre": 0})

    with open(PANEL_HTML, 'r', encoding='utf-8') as f:
        html = f.read()

    # Sincronización de dinero
    html = re.sub(r'id="gold-val"[^>]*>\d+<', f'id="gold-val" class="text-base font-black text-amber-300">{monedas.get("oro", 0)}<', html)
    html = re.sub(r'id="silver-val"[^>]*>\d+<', f'id="silver-val" class="text-base font-black text-slate-200">{monedas.get("plata", 0)}<', html)
    html = re.sub(r'id="copper-val"[^>]*>\d+<', f'id="copper-val" class="text-base font-black text-orange-300">{monedas.get("cobre", 0)}<', html)

    with open(PANEL_HTML, 'w', encoding='utf-8') as f:
        f.write(html)

if __name__ == "__main__":
    st = cargar_estado()
    actualizar_panel_html(st)
    print("Sincronización de estado y panel HTML completada.")
