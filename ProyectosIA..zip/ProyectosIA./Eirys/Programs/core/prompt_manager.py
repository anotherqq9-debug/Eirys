import os
import json

CONVERSATION_ID = "7e8364db-c852-4d61-b5bc-3c6d1a1f246e"
BASE_DIR = f"/home/vola3s/.gemini/antigravity/brain/{CONVERSATION_ID}"
SCRATCH_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02/mopaly_system"
TRANSCRIPT_PATH = f"{BASE_DIR}/.system_generated/logs/transcript.jsonl"
OUT_HISTORY = f"{SCRATCH_DIR}/mopaly_history_full.txt"
OUT_CONTEXT = f"{SCRATCH_DIR}/mopaly_context_auto.txt"

def extract_and_build():
    os.makedirs(SCRATCH_DIR, exist_ok=True)
    
    if not os.path.exists(TRANSCRIPT_PATH):
        print(f"Transcript file not initialized at {TRANSCRIPT_PATH}")
        return

    history_entries = []
    user_requests = []
    assistant_responses = []

    with open(TRANSCRIPT_PATH, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line.strip())
                step_type = data.get("type")
                content = data.get("content", "")
                created_at = data.get("created_at", "")
                
                if step_type == "USER_INPUT" and content:
                    clean_text = content.replace("<USER_REQUEST>", "").replace("</USER_REQUEST>", "").strip()
                    history_entries.append(f"[{created_at}] [USER]:\n{clean_text}\n")
                    user_requests.append(clean_text)
                
                elif step_type == "PLANNER_RESPONSE" and content:
                    history_entries.append(f"[{created_at}] [NARRADOR/IA]:\n{content}\n")
                    assistant_responses.append(content)
            except Exception:
                continue

    with open(OUT_HISTORY, 'w', encoding='utf-8') as f:
        f.write("=== HISTORIAL LAB 01 ===\n\n")
        f.write("\n".join(history_entries))
    
    print(f"Historial guardado en: {OUT_HISTORY} ({len(history_entries)} entradas)")

if __name__ == "__main__":
    extract_and_build()
