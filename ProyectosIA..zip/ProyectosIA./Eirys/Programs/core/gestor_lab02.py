import os

LAB_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
RULES_TXT = os.path.join(LAB_DIR, "mopaly_system", "reglas_narrativas.txt")
FICHA_TXT = os.path.join(LAB_DIR, "mopaly_system", "ficha_personaje_izanagi.txt")
USER_FICHA_TXT = os.path.join(LAB_DIR, "Main", "personaje_usuario", "ficha_izanagi.txt")

def cargar_reglas():
    if os.path.exists(RULES_TXT):
        with open(RULES_TXT, 'r', encoding='utf-8') as f:
            return f.read()
    return "Reglas no encontradas."

def cargar_ficha():
    if os.path.exists(FICHA_TXT):
        with open(FICHA_TXT, 'r', encoding='utf-8') as f:
            return f.read()
    return "Ficha no encontrada."

def actualizar_inventario(nuevos_items):
    if os.path.exists(USER_FICHA_TXT):
        with open(USER_FICHA_TXT, 'a', encoding='utf-8') as f:
            f.write(f"\n[ACTUALIZACIÓN INVENTARIO]\n{nuevos_items}\n")
        print("Ficha actualizada correctamente.")

if __name__ == "__main__":
    print("=== GESTOR LAB 01: IZANAGI ===")
    print("Reglas cargadas:", len(cargar_reglas()), "caracteres.")
    print("Ficha de Izanagi cargada:", len(cargar_ficha()), "caracteres.")
