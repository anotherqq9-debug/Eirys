#!/usr/bin/env python3
"""
MÓDULO DE DIAGNÓSTICO Y CONEXIÓN GENTLEMAN AI + ENGRAM (RESOLVEDOR DE PROBLEMAS)
Linux Environment: Bazzite / Fedora Atomic Gaming Edition
Client: Antigravity Code Assistant
"""

import os
import sys
import json
import subprocess
import socketserver
import http.server

BASE_SCRATCH_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
HOST_LAB_DIR = "/home/vola3s/LAB_02"

# Directorios de Configuración Persistente (Gentle AI & Engram)
CONFIG_DIRS = {
    "gentle_ai": os.path.join(BASE_SCRATCH_DIR, "configuraciones", "gentle_ai"),
    "engram": os.path.join(BASE_SCRATCH_DIR, "configuraciones", "engram"),
    "historial": os.path.join(BASE_SCRATCH_DIR, "Main", "historial"),
    "programas": os.path.join(BASE_SCRATCH_DIR, "programas_apoyo")
}

def inicializar_directorios_configuracion():
    print("=== [GENTLE AI & ENGRAM RESOLVEDOR DE PROBLEMAS] ===")
    print("1. Creando / verificando carpetas de configuración persistente...")
    for nombre, ruta in CONFIG_DIRS.items():
        os.makedirs(ruta, exist_ok=True)
        print(f"   ✓ Carpeta activa: {ruta}")

def reparar_rutas_recursos_html():
    print("\n2. Diagnosticando y reparando enlaces de imágenes en visores HTML...")
    archivos_html = [
        os.path.join(BASE_SCRATCH_DIR, "Main", "escenario", "atlas_interactivo_lab02.html"),
        os.path.join(HOST_LAB_DIR, "atlas_interactivo_lab02.html"),
        os.path.join(BASE_SCRATCH_DIR, "Main", "escenario", "panel_estado.html"),
        os.path.join(HOST_LAB_DIR, "panel_estado.html")
    ]
    
    for ruta in archivos_html:
        if os.path.exists(ruta):
            with open(ruta, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Reemplazar rutas absolutas rotas por nombres relativos dentro del servidor HTTP local
            if "/home/vola3s/.gemini/antigravity/brain/" in content:
                content_fixed = content.replace(
                    "/home/vola3s/.gemini/antigravity/brain/7e8364db-c852-4d61-b5bc-3c6d1a1f246e/mapa_cuatro_reinos_lab02_1790466949205.jpg",
                    "mapa_cuatro_reinos_lab02.jpg"
                )
                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(content_fixed)
                print(f"   ✓ Enlace de imagen corregido en: {ruta}")
            else:
                print(f"   ✓ Enlace de imagen ya verificado en: {ruta}")

def verificar_engram_y_gentle_ai():
    print("\n3. Verificando estado del resolvedor Gentle AI & puente Engram...")
    gentle_cfg = os.path.join(CONFIG_DIRS["gentle_ai"], "gentle_protocol.json")
    engram_cfg = os.path.join(CONFIG_DIRS["engram"], "engram_index.json")
    
    data_gentle = {
        "sistema_os": "Linux Bazzite (Fedora Atomic Gaming)",
        "asistente": "Antigravity (Google Deepmind)",
        "modo_resolucion": "Gentle AI + Engram Auto-Repair",
        "estado": "ACTIVO"
    }
    
    with open(gentle_cfg, "w", encoding="utf-8") as f:
        json.dump(data_gentle, f, indent=2)
    print(f"   ✓ Protocolo Gentle AI guardado en: {gentle_cfg}")

    data_engram = {
        "proyecto": "LAB_02",
        "indexacion_automatica": True,
        "historial_txt": os.path.join(CONFIG_DIRS["historial"], "historial_intercambios.txt")
    }
    with open(engram_cfg, "w", encoding="utf-8") as f:
        json.dump(data_engram, f, indent=2)
    print(f"   ✓ Índice de Engram configurado en: {engram_cfg}")

if __name__ == "__main__":
    inicializar_directorios_configuracion()
    reparar_rutas_recursos_html()
    verificar_engram_y_gentle_ai()
    print("\n=== [DIAGNÓSTICO COMPLETO CON ÉXITO] ===")
