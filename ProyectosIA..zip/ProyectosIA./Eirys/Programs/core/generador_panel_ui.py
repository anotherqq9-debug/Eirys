"""
Módulo del Sistema: Generador Dinámico de Panel UI (Eirys Punto Cero)
Sincronización Automática en Tiempo Real de Artefactos HTML
"""

import os
import sys
import json
import re

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
STATE_JSON = os.path.join(BASE_DIR, "Inventario", "estado_inventario.json")
ESCENARIO_JSON = os.path.join(BASE_DIR, "Escenario", "estado_escenario.json")
RELOJ_JSON = os.path.join(BASE_DIR, "Reloj", "cronologia_reloj.json")
NPC_JSON = os.path.join(BASE_DIR, "NPC", "registro_maestro_npcs.json")
PERSONAJE_MD = os.path.join(BASE_DIR, "Personaje", "ficha_personaje_usuario.md")
LOCAL_UI = os.path.join(BASE_DIR, "Programs", "UI", "panel_estado_ui.html")

# Artefacto en sesión actual si existe
CONV_ID = "d40ad053-d44a-480d-b285-c25fbfd8adcf"
ARTIFACT_DIR = f"/home/vola3s/.gemini/antigravity/brain/{CONV_ID}"
ARTIFACT_UI = os.path.join(ARTIFACT_DIR, "panel_estado_ui.html")

def generar_y_sincronizar_panel():
    os.makedirs(os.path.dirname(LOCAL_UI), exist_ok=True)

    # 1. Cargar Reloj
    reloj_texto = "Día 1 — 08:00 AM (Inicio)"
    if os.path.exists(RELOJ_JSON):
        try:
            with open(RELOJ_JSON, 'r', encoding='utf-8') as f:
                r_data = json.load(f)
                reloj_texto = f"Día {r_data.get('dia_actual', 1)} — {r_data.get('hora_actual', '08:00 AM')} ({r_data.get('fase_del_dia', 'Mañana')})"
        except Exception:
            pass

    # 2. Cargar Escenario
    ubicacion_str = "Punto de Inicio [Por definir]"
    bioma_str = "Entorno inicial"
    clima_str = "Despejado"
    if os.path.exists(ESCENARIO_JSON):
        try:
            with open(ESCENARIO_JSON, 'r', encoding='utf-8') as f:
                esc = json.load(f)
                ubic = esc.get("ubicacion_actual", {})
                ubicacion_str = f"{ubic.get('punto_especifico', 'Punto Inicial')} — {ubic.get('region', '')}"
                cond = esc.get("condiciones_ambientales", {})
                bioma_str = cond.get("bioma", "Neutro")
                clima_str = f"{cond.get('clima', 'Despejado')} ({cond.get('temperatura', 'Templada')})"
        except Exception:
            pass

    # 3. Cargar Inventario y Tesorería
    oro, plata, cobre = 0, 0, 0
    items_count = 0
    if os.path.exists(STATE_JSON):
        try:
            with open(STATE_JSON, 'r', encoding='utf-8') as f:
                inv = json.load(f)
                tes = inv.get("tesoreria", {})
                oro = tes.get("oro", 0)
                plata = tes.get("plata", 0)
                cobre = tes.get("cobre", 0)
                items_count = len(inv.get("inventario_completo", []))
        except Exception:
            pass

    # 4. Cargar Personaje (Ficha)
    nombre_p = "Protagonista [Pendiente Ficha]"
    rol_p = "Viajero / Aventurero"
    if os.path.exists(PERSONAJE_MD):
        try:
            with open(PERSONAJE_MD, 'r', encoding='utf-8') as f:
                txt = f.read()
                m_nom = re.search(r"-\s*\*\*Nombre:\*\*\s*(.+)", txt)
                if m_nom and "[Por definir]" not in m_nom.group(1):
                    nombre_p = m_nom.group(1).strip()
                m_rol = re.search(r"-\s*\*\*Clase / Rol:\*\*\s*(.+)", txt)
                if m_rol and "[Por definir]" not in m_rol.group(1):
                    rol_p = m_rol.group(1).strip()
        except Exception:
            pass

    # 5. Cargar NPCs
    npcs_count = 0
    if os.path.exists(NPC_JSON):
        try:
            with open(NPC_JSON, 'r', encoding='utf-8') as f:
                data_npc = json.load(f)
                npcs_count = len(data_npc.get("npcs_activos", {}))
        except Exception:
            pass

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Control - Eirys 1.0 (Punto Cero)</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {{ background-color: #0b0f19; color: #e2e8f0; font-family: ui-sans-serif, system-ui, sans-serif; }}
    .glass-card {{ background: rgba(15, 23, 42, 0.85); border: 1px solid #334155; backdrop-filter: blur(8px); }}
  </style>
</head>
<body class="p-4 md:p-6 text-slate-100 antialiased">
  <div class="max-w-6xl mx-auto space-y-6">
    
    <!-- Header -->
    <div class="glass-card p-6 rounded-2xl border-cyan-500/30 flex flex-wrap justify-between items-center gap-4">
      <div>
        <div class="flex items-center gap-3">
          <h1 class="text-3xl font-extrabold text-cyan-400 tracking-wide">{nombre_p}</h1>
          <span class="px-3 py-1 bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs font-bold rounded-full">EIRYS 1.0 • PUNTO CERO</span>
        </div>
        <p class="text-sm text-slate-400 mt-1">{rol_p} • Estado Canónico: Inicial</p>
      </div>
      <div class="flex items-center gap-3 bg-slate-900/80 px-4 py-2.5 rounded-xl border border-slate-700">
        <span class="text-xs uppercase tracking-wider text-slate-400 font-semibold">Cronología:</span>
        <span class="text-sm font-mono text-cyan-300 font-bold">{reloj_texto}</span>
      </div>
    </div>

    <!-- Grid de Métricas Principales -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      
      <!-- Ubicación y Entorno -->
      <div class="glass-card p-5 rounded-xl border-slate-700">
        <h3 class="text-xs uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-2">
          📍 Ubicación & Entorno
        </h3>
        <p class="text-lg font-bold text-slate-100 mt-2">{ubicacion_str}</p>
        <p class="text-xs text-slate-400 mt-1">Bioma: <span class="text-slate-200">{bioma_str}</span></p>
        <p class="text-xs text-slate-400">Clima: <span class="text-slate-200">{clima_str}</span></p>
      </div>

      <!-- Tesorería -->
      <div class="glass-card p-5 rounded-xl border-slate-700">
        <h3 class="text-xs uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-2">
          💰 Tesorería & Economía
        </h3>
        <div class="flex items-center gap-4 mt-3">
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-amber-400 inline-block"></span><span class="font-bold text-amber-300">{oro}</span> <span class="text-xs text-slate-400">Oro</span></div>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-slate-300 inline-block"></span><span class="font-bold text-slate-200">{plata}</span> <span class="text-xs text-slate-400">Plata</span></div>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-amber-700 inline-block"></span><span class="font-bold text-amber-600">{cobre}</span> <span class="text-xs text-slate-400">Cobre</span></div>
        </div>
        <p class="text-xs text-slate-400 mt-3">Objetos registrados: <span class="text-slate-200 font-semibold">{items_count}</span></p>
      </div>

      <!-- Matriz Social -->
      <div class="glass-card p-5 rounded-xl border-slate-700">
        <h3 class="text-xs uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-2">
          👥 Matriz Social & NPCs
        </h3>
        <p class="text-2xl font-bold text-cyan-400 mt-2">{npcs_count} <span class="text-xs text-slate-400 font-normal">NPCs Activos</span></p>
        <p class="text-xs text-slate-400 mt-1">Base de datos lista para indexar nuevos encuentros.</p>
      </div>
    </div>

    <!-- Footer / Status -->
    <div class="glass-card p-4 rounded-xl border-slate-800 text-xs text-slate-500 flex justify-between items-center">
      <span>Eirys Simulation Engine • GentlemanProgram 4.2 Desacoplado</span>
      <span class="text-emerald-400 font-semibold">● Sistema Sincronizado</span>
    </div>

  </div>
</body>
</html>
"""
    with open(LOCAL_UI, 'w', encoding='utf-8') as f:
        f.write(html)
        
    if os.path.exists(ARTIFACT_DIR):
        try:
            with open(ARTIFACT_UI, 'w', encoding='utf-8') as f:
                f.write(html)
        except Exception:
            pass

    return True

if __name__ == "__main__":
    ok = generar_y_sincronizar_panel()
    print(f"[PANEL UI]: Generado con éxito en '{LOCAL_UI}' (Sincronizado: {ok})")
