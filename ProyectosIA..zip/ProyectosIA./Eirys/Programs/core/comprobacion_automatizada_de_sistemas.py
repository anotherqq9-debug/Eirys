"""
Módulo Maestro: Comprobación Automatizada de Sistemas (Eirys 1.0)
GentlemanProgram 4.2 Integrado (Punto Cero)
Función: comprobacion_automatizada_de_sistemas()

Realiza una auditoría exhaustiva de:
1. Integridad de archivos y persistencia del canon en Eirys.
2. Cumplimiento de los 14 Motores Narrativos de GentlemanProgram.
3. Hechos Epistémicos Inmutables (Anti-Amnesia y Memoria Factual).
4. Cortafuegos de Privacidad y Agencia del Protagonista.
5. Estado Factual de Inventario y Tesorería.
6. Matriz Social y Memoria de NPCs.
7. Regla de Coherencia Geológica y Cartográfica (Atlas de Hinomoto).
8. Sincronización en Tiempo Real del Panel de Estado UI y Mapa Interactivo.
9. Clasificación y Archivamiento Automático de Errores.
"""

import os
import sys
import json
import re
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

PROGRAMS_DIR = os.path.join(BASE_DIR, "Programs")
if PROGRAMS_DIR not in sys.path:
    sys.path.insert(0, PROGRAMS_DIR)

STATE_FILE = os.path.join(BASE_DIR, "Inventario", "estado_inventario.json")
ESCENARIO_FILE = os.path.join(BASE_DIR, "Escenario", "estado_escenario.json")
RELOJ_FILE = os.path.join(BASE_DIR, "Reloj", "cronologia_reloj.json")
NPC_FILE = os.path.join(BASE_DIR, "NPC", "registro_maestro_npcs.json")
SOCIAL_FILE = os.path.join(BASE_DIR, "Red Social", "matriz_relaciones_sociales.json")
RULES_FILE = os.path.join(BASE_DIR, "Reglas", "compendio_reglas_maestras.md")
PERSONAJE_FILE = os.path.join(BASE_DIR, "Personaje", "ficha_personaje_usuario.md")
CANON_FILE = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Positivo", "registro_canon_admitido.json")
ATLAS_FILE = os.path.join(BASE_DIR, "Mapa o GPS", "atlas_geografico.json")
MAP_INTERACTIVE_SCRIPT = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "generador_mapa_interactivo.py")
ERRORS_LOG_FILE = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Negativo", "registro_errores_y_soluciones.json")
CERT_LOG_FILE = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Positivo", "registro_certificaciones_sistema.json")

def comprobacion_automatizada_de_sistemas(texto_a_validar=None, archivar_siempre=False):
    print("===============================================================================")
    print("🔍 INICIANDO COMPROBACIÓN AUTOMATIZADA DE SISTEMAS (EIRYS 1.0 - PUNTO CERO)")
    print("===============================================================================")

    resultado = {
        "timestamp": datetime.now().isoformat(),
        "estado_general": "CERTIFICADO_OK",
        "archivos_auditados": {},
        "motores_evaluados": 15,
        "hechos_epistemicos_auditados": 0,
        "npcs_verificados": 0,
        "fallas_detectadas": [],
        "ui_sincronizado": False,
        "mapa_sincronizado": False,
        "resumen": ""
    }

    # 1. VERIFICACIÓN DE ESTRUCTURA Y ARCHIVOS CRÍTICOS
    archivos_criticos = {
        "inventario": STATE_FILE,
        "escenario": ESCENARIO_FILE,
        "reloj": RELOJ_FILE,
        "registro_npcs": NPC_FILE,
        "red_social": SOCIAL_FILE,
        "reglas_maestras": RULES_FILE,
        "ficha_personaje": PERSONAJE_FILE,
        "canon_positivo": CANON_FILE,
        "atlas_geografico": ATLAS_FILE,
        "registro_errores": ERRORS_LOG_FILE
    }

    for clave, ruta in archivos_criticos.items():
        existe = os.path.exists(ruta)
        resultado["archivos_auditados"][clave] = "OK" if existe else "FALTANTE"
        if not existe:
            resultado["fallas_detectadas"].append({
                "motor": "SISTEMA_ARCHIVOS",
                "codigo": f"ERR_FILE_MISSING_{clave.upper()}",
                "severidad": "CRITICA",
                "descripcion": f"Archivo crítico del sistema no encontrado en Eirys: {ruta}"
            })

    if any(res == "FALTANTE" for res in resultado["archivos_auditados"].values()):
        resultado["estado_general"] = "FALLA_ESTRUCTURAL"
        _archivar_resultado(resultado)
        _imprimir_reporte(resultado)
        return resultado

    # Cargar y validar JSONs
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            inv_data = json.load(f)
        with open(RELOJ_FILE, 'r', encoding='utf-8') as f:
            reloj_data = json.load(f)
        with open(ESCENARIO_FILE, 'r', encoding='utf-8') as f:
            esc_data = json.load(f)
        with open(NPC_FILE, 'r', encoding='utf-8') as f:
            npc_data = json.load(f)
        with open(CANON_FILE, 'r', encoding='utf-8') as f:
            canon_data = json.load(f)
        with open(ATLAS_FILE, 'r', encoding='utf-8') as f:
            atlas_data = json.load(f)
    except Exception as e:
        resultado["fallas_detectadas"].append({
            "motor": "PARSER_JSON",
            "codigo": "ERR_JSON_CORRUPTED",
            "severidad": "CRITICA",
            "descripcion": f"Fallo al parsear estructura de datos JSON en Eirys: {str(e)}"
        })
        resultado["estado_general"] = "FALLA_ESTRUCTURAL"
        _archivar_resultado(resultado)
        _imprimir_reporte(resultado)
        return resultado

    # 2. AUDITORÍA DE HECHOS EPISTÉMICOS
    hechos = canon_data.get("hechos_canonicos", [])
    resultado["hechos_epistemicos_auditados"] = len(hechos)

    # 3. AUDITORÍA DE NPCS
    npcs_activos = npc_data.get("npcs_activos", {})
    resultado["npcs_verificados"] = len(npcs_activos)

    # 4. AUDITORÍA DE COHERENCIA GEOLÓGICA Y ASOCIACIÓN A REINOS
    pos_actual = atlas_data.get("posicion_jugador_actual", {})
    if not pos_actual.get("coordenadas_mapa"):
        resultado["fallas_detectadas"].append({
            "motor": "COHERENCIA_GEOLOGICA",
            "codigo": "ERR_GEO_COORDINATES_MISSING",
            "severidad": "MEDIA",
            "descripcion": "Faltan las coordenadas geológicas del usuario en atlas_geografico.json."
        })

    # Verificar que existen los 4 reinos principales y el continente demoniaco
    reinos = atlas_data.get("reinos_principales", {})
    reinos_requeridos = ["reino_1_humano_yamashiro", "reino_2_demihumano_kamishiro", "reino_3_elfo_shinrai", "reino_4_enano_tatsumigane"]
    for req_r in reinos_requeridos:
        if req_r not in reinos:
            resultado["fallas_detectadas"].append({
                "motor": "COHERENCIA_GEOLOGICA",
                "codigo": f"ERR_KINGDOM_MISSING_{req_r.upper()}",
                "severidad": "ALTA",
                "descripcion": f"Falta el reino oficial '{req_r}' en la base geográfica."
            })

    # Validar texto si fue provisto
    if texto_a_validar:
        txt_l = texto_a_validar.lower()
        try:
            from GentlemanProgram.detector_fallas_gentleman import ValidatorNarrativoGentleman
            validador = ValidatorNarrativoGentleman()
            valido, fallas_motores = validador.validar_respuesta(texto_a_validar)
            if not valido:
                for fm in fallas_motores:
                    resultado["fallas_detectadas"].append({
                        "motor": fm.get("motor", "GENTLEMAN_ENGINE"),
                        "codigo": fm.get("codigo", "ERR_GENTLEMAN"),
                        "severidad": "MEDIA",
                        "descripcion": fm.get("descripcion", "Falla detectada por motor narrativo")
                    })
        except Exception as e:
            resultado["fallas_detectadas"].append({
                "motor": "GENTLEMAN_RUNNER",
                "codigo": "ERR_VALIDATOR_EXCEPTION",
                "severidad": "MEDIA",
                "descripcion": f"Error ejecutando ValidatorNarrativoGentleman: {str(e)}"
            })

    # 5. SINCRONIZACIÓN AUTOMÁTICA DEL PANEL UI
    try:
        from core.generador_panel_ui import generar_y_sincronizar_panel, LOCAL_UI
        sync_ok = generar_y_sincronizar_panel()
        resultado["ui_sincronizado"] = sync_ok and os.path.exists(LOCAL_UI)
    except Exception as e:
        resultado["fallas_detectadas"].append({
            "motor": "SINCRONIZADOR_UI",
            "codigo": "ERR_UI_GENERATOR_FAIL",
            "severidad": "BAJA",
            "descripcion": f"Fallo al ejecutar generador_panel_ui: {str(e)}"
        })

    # 6. SINCRONIZACIÓN AUTOMÁTICA DEL MAPA CARTOGRÁFICO INTERACTIVO
    try:
        from Mapa_o_GPS.interfaz.generador_mapa_interactivo import generar_mapa_html, LOCAL_MAP_HTML
    except ImportError:
        # Import dinámico si el nombre de carpeta tiene espacios
        import importlib.util
        spec = importlib.util.spec_from_file_location("generador_mapa_interactivo", MAP_INTERACTIVE_SCRIPT)
        map_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(map_mod)
        generar_mapa_html = map_mod.generar_mapa_html
        LOCAL_MAP_HTML = map_mod.LOCAL_MAP_HTML

    try:
        map_ok = generar_mapa_html()
        resultado["mapa_sincronizado"] = map_ok and os.path.exists(LOCAL_MAP_HTML)
    except Exception as e:
        resultado["fallas_detectadas"].append({
            "motor": "SINCRONIZADOR_MAPA",
            "codigo": "ERR_MAP_GENERATOR_FAIL",
            "severidad": "BAJA",
            "descripcion": f"Fallo al ejecutar generador_mapa_interactivo: {str(e)}"
        })

    # 7. ESTADO FINAL
    if resultado["fallas_detectadas"]:
        resultado["estado_general"] = "ANOMALÍAS_DETECTADAS"
        resultado["resumen"] = f"Se detectaron {len(resultado['fallas_detectadas'])} anomalías durante la comprobación de sistemas."
    else:
        resultado["estado_general"] = "CERTIFICADO_OK"
        resultado["resumen"] = "Sistema Eirys 100% íntegro, coherente y en Punto Cero. Atlas cartográfico y geológico sincronizado."

    _archivar_resultado(resultado, archivar_siempre=archivar_siempre)
    _imprimir_reporte(resultado)
    return resultado

def _archivar_resultado(resultado, archivar_siempre=False):
    os.makedirs(os.path.dirname(ERRORS_LOG_FILE), exist_ok=True)
    if resultado["fallas_detectadas"]:
        log_existente = []
        if os.path.exists(ERRORS_LOG_FILE):
            try:
                with open(ERRORS_LOG_FILE, 'r', encoding='utf-8') as f:
                    content = json.load(f)
                    log_existente = content.get("errores", [])
            except Exception:
                log_existente = []
        log_existente.append({
            "timestamp": resultado["timestamp"],
            "estado": resultado["estado_general"],
            "fallas": resultado["fallas_detectadas"]
        })
        with open(ERRORS_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump({"errores": log_existente}, f, indent=2, ensure_ascii=False)
    elif archivar_siempre or resultado["estado_general"] == "CERTIFICADO_OK":
        cert_existente = []
        if os.path.exists(CERT_LOG_FILE):
            try:
                with open(CERT_LOG_FILE, 'r', encoding='utf-8') as f:
                    cert_existente = json.load(f)
            except Exception:
                cert_existente = []
        cert_existente.append({
            "timestamp": resultado["timestamp"],
            "estado": "CERTIFICADO_OK",
            "resumen": resultado["resumen"],
            "mapa_sincronizado": resultado["mapa_sincronizado"]
        })
        with open(CERT_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(cert_existente[-50:], f, indent=2, ensure_ascii=False)

def _imprimir_reporte(res):
    print("-------------------------------------------------------------------------------")
    print(f"📊 ESTADO GENERAL: {res['estado_general']}")
    print(f"✓ Motores Narrativos y Geológicos Evaluados: {res['motores_evaluados']}")
    print(f"✓ Hechos Epistémicos Inmutables Auditados: {res['hechos_epistemicos_auditados']}")
    print(f"✓ NPCs Activos en Base de Datos: {res['npcs_verificados']}")
    print(f"✓ Sincronización del Panel de Estado UI: {'EXITOSA' if res['ui_sincronizado'] else 'FALLIDA'}")
    print(f"✓ Sincronización del Mapa Interactivo: {'EXITOSA' if res['mapa_sincronizado'] else 'FALLIDA'}")
    print(f"✓ Resumen: {res['resumen']}")
    if res["fallas_detectadas"]:
        print("⚠️ DETALLE DE ANOMALÍAS:")
        for idx, f in enumerate(res["fallas_detectadas"], 1):
            print(f"  {idx}. [{f.get('motor')}] ({f.get('codigo')}): {f.get('descripcion')}")
    else:
        print("✓ CERO ANOMALÍAS: Entorno Eirys validado y desacoplado exitosamente.")
    print("===============================================================================\n")

if __name__ == "__main__":
    comprobacion_automatizada_de_sistemas(archivar_siempre=True)
