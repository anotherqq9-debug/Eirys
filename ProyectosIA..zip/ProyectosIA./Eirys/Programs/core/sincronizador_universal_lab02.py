import os
import sys
BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import json
import re

BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
STATE_JSON = os.path.join(BASE_DIR, "mopaly_system", "estado_usuario.json")
PANEL_HTML = os.path.join(BASE_DIR, "Main", "escenario", "panel_estado.html")

def sincronizar_todo():
    if not os.path.exists(STATE_JSON) or not os.path.exists(PANEL_HTML):
        return False

    with open(STATE_JSON, 'r', encoding='utf-8') as f:
        st = json.load(f)

    p = st.get("personaje", {})
    monedas = p.get("monedas", {"oro": 0, "plata": 0, "cobre": 0})
    ubicacion = p.get("ubicacion_actual", {})
    inv = p.get("inventario", [])
    salud_str = p.get("salud", "100%")
    estamina_str = p.get("estammina", "100%")
    heridas = p.get("heridas_y_secuelas", [])

    with open(PANEL_HTML, 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Monedas
    html = re.sub(r'id="gold-val"[^>]*>\d+<', f'id="gold-val" class="text-base font-black text-amber-300">{monedas.get("oro", 0)}<', html)
    html = re.sub(r'id="silver-val"[^>]*>\d+<', f'id="silver-val" class="text-base font-black text-slate-200">{monedas.get("plata", 0)}<', html)
    html = re.sub(r'id="copper-val"[^>]*>\d+<', f'id="copper-val" class="text-base font-black text-orange-300">{monedas.get("cobre", 0)}<', html)

    # 2. Ubicación
    punto = ubicacion.get("punto_especifico", "Zona No Mapeada")
    html = re.sub(r'id="geo-location"[^>]*>.*?<', f'id="geo-location" class="text-emerald-300 font-bold">📍 {punto}<', html)

    # 3. Inventario
    inv_html_items = ""
    for item in inv:
        nombre = item.get("item", "Objeto")
        estado = item.get("estado", "")
        cant = item.get("cantidad", 1)
        inv_html_items += f'''
        <div class="p-3 bg-slate-900 rounded-xl border border-slate-800">
          <div class="flex justify-between items-center">
            <span class="font-bold text-slate-200">📦 {nombre}</span>
            <span class="bg-slate-800 text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded">x{cant}</span>
          </div>
          <p class="text-slate-400 text-[11px] mt-1">{estado}</p>
        </div>'''

    if inv_html_items:
        html = re.sub(r'<div id="inventory-list"[^>]*>.*?</div>\s*</div>\s*</div>\s*</details>', 
                      f'<div id="inventory-list" class="space-y-2 text-xs max-h-[420px] overflow-y-auto pr-1">{inv_html_items}</div></div></div></details>', 
                      html, flags=re.DOTALL)

    # 4. Heridas y Secuelas Biológicas
    heridas_html = ""
    if not heridas:
        heridas_html = '<div class="p-2.5 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">✓ Sin lesiones físicas ni secuelas activas.</div>'
    else:
        for h in heridas:
            heridas_html += f'''
            <div class="p-2.5 bg-rose-950/40 border border-rose-500/30 rounded-xl text-xs space-y-1">
              <span class="font-bold text-rose-300">⚠️ {h.get("zona", "Cuerpo")}: {h.get("tipo", "Lesión")}</span>
              <p class="text-slate-300 text-[11px]">{h.get("efecto", "Sin secuela descrita")}</p>
            </div>'''

    html = re.sub(r'<div id="health-status"[^>]*>.*?</div>\s*</div>', 
                  f'<div id="health-status" class="space-y-2 text-xs">{heridas_html}</div></div>', 
                  html, flags=re.DOTALL)

    with open(PANEL_HTML, 'w', encoding='utf-8') as f:
        f.write(html)

    
    # Sincronización Automática Integral de Artefactos UI
    try:
        from mopaly_system.generador_panel_ui import generar_y_sincronizar_panel
        generar_y_sincronizar_panel()
    except Exception as e:
        print(f"Error sincronizando panel UI: {e}")

    print("[SINCRONIZADOR UNIVERSAL LAB 02]: Sincronización completa con salud, secuelas y artefacto UI en vivo.")
    return True

if __name__ == "__main__":
    sincronizar_todo()
