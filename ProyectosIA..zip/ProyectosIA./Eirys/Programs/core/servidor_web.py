import http.server
import socketserver
import os

PORT = 8080
DIRECTORY = "/home/vola3s/.gemini/antigravity/scratch/LAB_02/Main/escenario"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

if __name__ == "__main__":
    os.chdir(DIRECTORY)
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Servidor HTTP corriendo en http://localhost:{PORT}")
        httpd.serve_forever()
