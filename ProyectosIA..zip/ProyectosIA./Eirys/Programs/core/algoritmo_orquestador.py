import os
import sys
import json
import subprocess

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
MAESTRO_RULES = os.path.join(BASE_DIR, "Reglas", "compendio_reglas_maestras.md")
FICHA_PERSONAJE = os.path.join(BASE_DIR, "Personaje", "ficha_personaje_usuario.md")
STATE_JSON = os.path.join(BASE_DIR, "Inventario", "estado_inventario.json")
NPC_JSON = os.path.join(BASE_DIR, "NPC", "registro_maestro_npcs.json")
ESCENARIO_JSON = os.path.join(BASE_DIR, "Escenario", "estado_escenario.json")
RELOJ_JSON = os.path.join(BASE_DIR, "Reloj", "cronologia_reloj.json")
CANON_JSON = os.path.join(BASE_DIR, "Programs", "Historial Narrativo Positivo", "registro_canon_admitido.json")

def cargar_contexto_completo():
    contexto = {}
    if os.path.exists(MAESTRO_RULES):
        with open(MAESTRO_RULES, 'r', encoding='utf-8') as f:
            contexto['reglas'] = f.read()
    if os.path.exists(FICHA_PERSONAJE):
        with open(FICHA_PERSONAJE, 'r', encoding='utf-8') as f:
            contexto['ficha_personaje'] = f.read()
    if os.path.exists(STATE_JSON):
        with open(STATE_JSON, 'r', encoding='utf-8') as f:
            contexto['inventario'] = json.load(f)
    if os.path.exists(NPC_JSON):
        with open(NPC_JSON, 'r', encoding='utf-8') as f:
            contexto['npcs'] = json.load(f)
    if os.path.exists(ESCENARIO_JSON):
        with open(ESCENARIO_JSON, 'r', encoding='utf-8') as f:
            contexto['escenario'] = json.load(f)
    if os.path.exists(RELOJ_JSON):
        with open(RELOJ_JSON, 'r', encoding='utf-8') as f:
            contexto['reloj'] = json.load(f)
    return contexto

def ejecutar_orquestador_completo():
    print("=== PIPELINE ENGINE ORQUESTADOR CANON (EIRYS 1.0) ===")
    
    # 1. Comprobación y Sincronización
    comprobador = os.path.join(BASE_DIR, "Programs", "GentlemanProgram", "comprobacion_automatizada_de_sistemas.py")
    if os.path.exists(comprobador):
        try:
            res = subprocess.run([sys.executable, comprobador], capture_output=True, text=True)
            print(res.stdout.strip())
        except Exception as e:
            print(f"⚠️ Error en Comprobación de Sistemas: {e}")

    ctx = cargar_contexto_completo()
    print(f"✓ Reglas Maestras Cargadas: {len(ctx.get('reglas', ''))} caracteres.")
    print(f"✓ Ficha Protagonista: {'Enlazada' if 'ficha_personaje' in ctx else 'Faltante'}.")
    print(f"✓ Base de Datos NPCs: {len(ctx.get('npcs', {}).get('npcs_activos', {}))} activos.")
    print("\n[PIPELINE INTEGRAL OK]: Entorno Eirys enlazado y listo para iniciar la nueva campaña.")
    return True

if __name__ == "__main__":
    ejecutar_orquestador_completo()
