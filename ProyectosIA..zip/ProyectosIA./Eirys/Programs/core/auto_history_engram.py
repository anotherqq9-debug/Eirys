import os
import sys
BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import subprocess
import json

BASE_DIR = "/home/vola3s/.gemini/antigravity/scratch/LAB_02"
HISTORIAL_TXT = os.path.join(BASE_DIR, "mopaly_system", "mopaly_history_full.txt")
ENGRAM_BIN = os.path.join(BASE_DIR, "programas_apoyo", "engram")

def registrar_intercambio(usuario_texto, narrador_texto):
    os.makedirs(os.path.dirname(HISTORIAL_TXT), exist_ok=True)
    
    # Guardar la transcripción EXACTA e ÍNTEGRA sin recortar en el archivo de historial completo
    with open(HISTORIAL_TXT, "a", encoding="utf-8") as f:
        f.write(f"\n===================================================\n")
        f.write(f"[INTERCAMBIO EXACTO]\n")
        f.write(f"[USUARIO / IZANAGI]:\n{usuario_texto.strip()}\n\n")
        f.write(f"[SISTEMA / NARRATIVA]:\n{narrador_texto.strip()}\n")
        f.write("===================================================\n")
        
    print(f"[HISTORIAL ÍNTEGRO TXT]: Registrado exactamente sin resumir en {HISTORIAL_TXT}")
    # Sincronización automática de Estado y Panel UI en tiempo real
    try:
        from mopaly_system.sincronizador_universal_lab02 import sincronizar_todo
        sincronizar_todo()
    except Exception as e:
        print(f"Error en sincronización automática post-intercambio: {e}")

    # Comprobación Automatizada de Sistemas y Archivamiento de Errores
    try:
        from GentlemanProgram.comprobacion_automatizada_de_sistemas import comprobacion_automatizada_de_sistemas
        comprobacion_automatizada_de_sistemas(texto_a_validar=narrador_texto, archivar_siempre=True)
    except Exception as e:
        print(f"Error en comprobación automatizada de sistemas post-intercambio: {e}")

def buscar_hecho_historico_exacto(query):
    """
    Busca la ocurrencia literal dentro del archivo mopaly_history_full.txt
    """
    if not os.path.exists(HISTORIAL_TXT):
        return []
    
    resultados = []
    with open(HISTORIAL_TXT, "r", encoding="utf-8") as f:
        bloques = f.read().split("===================================================")
        for b in bloques:
            if query.lower() in b.lower():
                resultados.append(b.strip())
    return resultados

if __name__ == "__main__":
    print("Módulo de registro de historial integro listo en LAB 02.")
