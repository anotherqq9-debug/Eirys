# 🛠️ CATÁLOGO DE SOLUCIONES E INTEGRACIONES TÉCNICAS (GENTLEMAN)

| Código de Error | Descripción de la Falla | Solución Implementada | Motor Integrado |
| :--- | :--- | :--- | :--- |
|  | NPC usa términos de su lista prohibida o sabe cosas sin verlas. | Bloqueo pre-vuelo y matriz de términos prohibidos por NPC. | Motor 3 (Cognitivo NPC) |
|  | Narrador asume pensamientos o emociones del usuario. | Filtro regex de verbos de cognición en segunda persona. | Motor 4 (Agencia) |
|  | Inclusión de nombres occidentales no canónicos. | Lista negra nominativa estricta (Regla #72). | Motor 5 (Nomenclatura) |
|  | NPCs secundarios usan términos científicos avanzados. | Inspección de diálogos entre guiones (). | Motor 6 (Anti-Omnisciencia) |
|  | Prosa con palabras de videojuego (stats, barras de vida). | Purga de léxico RPG (Regla #3). | Motor 7 (Cero Gamificación) |
|  | NPCs mencionan trasfondo confidencial del protagonista. | Cortafuegos biográfico estricto. | Motor 9 (Cortafuegos) |
|  | Narrativa contradice hechos admitidos en el canon. | Cruce automático con regex de hechos certificados. | Motor 10 (Anti-Amnesia) |
|  | Describir báculos como pistolas mágicas de fuego espontáneo. | Exigencia de extracción física de munición y física vectorial. | Motor 14.a (Física Balística) |
|  | Disparo de proyectiles sin describir su recuperación. | Retracción obligatoria por hilos de gravedad (<0.5 s). | Motor 14.c (Recursos Finitos) |
|  | Describir técnica criogénica/endotérmica con combustión o fuego. | Bloqueo estricto de términos de calor en Purgatorio Blanco. | Motor 14.d (Coherencia Térmica) |
|  | Usar cántico de artillería ligera para artillería pesada. | Matriz de correlación táctica obligatoria de cánticos. | Motor 14.e (Matriz Táctica) |
