# 🛡️ PROTOCOLO DE ADMISIÓN DE CANON (ESTÁNDAR EIRYS)

1. **Recepción del Evento:** El evento ocurre en la narrativa mediante acción explícita del usuario o interacción validada.
2. **Evaluación de Coherencia:**
   - ¿Respeta la física y leyes del mundo?
   - ¿Respeta la Anti-Omnisciencia y límites sensoriales de los NPCs presentes?
   - ¿Mantiene la contabilidad de recursos e inventario?
   - ¿No contradice ningún hecho previamente admitido?
3. **Certificación e Indexación:** Se le asigna un ID único, se registran los NPCs enterados y se generan expresiones regulares de violación para la auditoría automática continua.
