# 👤 DOSSIER MAESTRO: IZAYA (PROTAGONISTA)

> **Estado:** Activo • Canon Eirys 1.0 (Punto Cero)  
> **Clasificación del Mundo:** Civil Rango E (No Registrado) • Nivel 8 Público  
> **Realidad Biológica:** Depredador Apex • Nivel Real: 97 x 18 ciclos de adaptación (Sin magia)

---

## 1. DATOS BIOGRÁFICOS Y DE IDENTIDAD
* **Nombre:** Izaya (Sin apellido).
* **Edad:** 30 años.
* **Condición Social:** Huérfano, analfabeto, sin gremio ni estatus social reconocible.
* **Lugar de Nacimiento Oficial:** Capital Imperial de Mizuhara (Reino Humano de Yamashiro). Huérfano de nacimiento en la capital, trasladado de infante al orfanato rural.
* **Historia Temprana (0-12 años):** Trasladado desde la Capital de Mizuhara, creció en el Orfanato Alkesta (situado en las tierras que hoy ocupan los Viñedos de Akisamu). Al ser interrogado burocráticamente por su origen, declara haber nacido en la Capital de Mizuhara, evitando levantar sospechas sobre su pasado o identidad oculta.
* **Trauma Fundacional (12 años):** Masacre del orfanato por bandidos; presenció la agresión y muerte de las niñas. Fractura de brazo y pierna. Arrojado al río Shiratsuyu y arrastrado kilómetros hasta el Bosque Profundo de Kurokura.
* **Aislamiento (12-30 años):** 18 años de supervivencia extrema en aislamiento absoluto sin contacto humano.
* **Estado Espiritual / Mental:** Fe en la humanidad y en dioses quebrada e inexistente.

---

## 2. BIOLOGÍA Y CAPACIDADES ADAPTATIVAS
* **Apariencia Externa:** Aspecto de vagabundo/mendigo rústico, delgado, piel curtida. Cero estética de guerrero o salvaje noble.
* **Biología Interna & Capacidades Sobrehumanas:** Músculos, tendones y densidad ósea hiper-adaptados por 'Evolución de Darwin'. Fuerza, agilidad y reflejos muy superiores al límite humano normal.
* **Percepción Sensorial (Rango S):** Rastreo absoluto, olfato hipersensible (sangre, miedo), audición de frecuencias imperceptibles, visión en penumbra densa.
* **Inmunidad / Resistencia Tóxica:** Sistema hepático e inmunológico adaptado por años de consumo de carroña, flora venenosa y aguas estancadas.
* **Ingeniería de Supervivencia:** Confección instintiva de trampas, cuerdas y armas con recursos naturales.

---

## 3. MECÁNICAS DE COMBATE Y HABILIDADES
* **Itto Aku (Trance de Hiperfoco Letal):**
  - *Gatillo:* Amenaza de muerte directa o defensa territorial/manada.
  - *Manifestación Física:* Dilatación temporal subjetiva, iris verde pardo muta a negro absoluto.
  - *Efecto:* Atributos físicos al límite biomecánico para neutralizar la amenaza al instante.
  - *Contra-efecto:* Agotamiento extremo y vulnerabilidad física/mental al cesar el trance.
* **Habilidad Única: Evolución de Darwin:**
  - *Activa:* Detonada en crisis fisiológicas o cognitivas severas tras trance de supervivencia.
  - *Pasiva:* Adaptación biológica continua ligada al entorno, dieta y necesidades de supervivencia.

---

## 4. PSICOLOGÍA Y DINÁMICA DE MANADA
* **Desarrollo Detenido:** Madurez emocional congelada a los 12 años con instintos de depredador apex.
* **Interpretación Literal:** Incomprensión de dinero, títulos, nobleza o burocracia. Toma todo literal.
* **Léxico:** Desconoce nombres oficiales de gremios o rangos; usa metáforas sensoriales ("metal brillante", "perro grande", "humano con olor a metal y sangre").
* **Comunicación:** Silencioso, voz áspera y oxidada por el desuso prolongado. Sonrisa infantil y cálida remanente de su niñez.
* **Ceguera Sociológica y Racial:** Cero prejuicios hacia humanos, demihumanos o monstruos.
* **Concepto de Manada:** Estrictamente animal y territorial (quien comparte comida, territorio y lealtad probada).
* **Gatillos Violentos Inmediatos:**
  1. Olor a miedo mezclado con sangre.
  2. Amenaza a miembros de su manada territorial.
  3. Gritos de niñas pequeñas (trauma primario de Akisamu).

---

## 5. INVENTARIO INICIAL
* **Mochila:** Cuero de ciervo curtido a mano, costuras rústicas, aroma a almizcle, humo y hierba seca.
* **Vestimenta:** Ropa rasgada reforzada con fibras vegetales; calzado de lianas trenzadas y cuero crudo.
* **Armas:** Dos Cuchillos de Hueso desgastados (10 a 15 cm). Forjados de los colmillos del Lobo Gigante Variante Mutante (Amenaza Catástrofe de Kisara cazado hace 14 años). Estructura hiperdensa, irrompible, superior al acero, aunque con apariencia de herramientas rústicas de novato.
* **Suministros:** Peras silvestres maduras recolectadas.
