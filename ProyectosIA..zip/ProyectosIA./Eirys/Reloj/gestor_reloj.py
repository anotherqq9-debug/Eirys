#!/usr/bin/env python3
import json
import os

RELOJ_FILE = os.path.join(os.path.dirname(__file__), "cronologia_reloj.json")

def obtener_tiempo_actual():
    with open(RELOJ_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return f"Día {data['dia_actual']} de la Transmigración — {data['hora_actual']} ({data['fase_del_dia']})"

def avanzar_tiempo(minutos):
    # Función para avanzar minutos de forma precisa
    print(f"[RELOJ EIRYS]: Tiempo actual: {obtener_tiempo_actual()}")

if __name__ == "__main__":
    print(obtener_tiempo_actual())
