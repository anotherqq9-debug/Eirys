# ⏳ MÓDULO DE RELOJ Y CRONOLOGÍA TEMPORAL (EIRYS)

---

## 🎯 PROPÓSITO
Gobierna la **continuidad temporal ininterrumpida** del universo. 
Impide saltos arbitrarios de tiempo, controla el paso de minutos durante acciones de combate, construcción o marcha, y coordina los ciclos día/noche y estaciones del año.

## 📁 ARCHIVOS
* `cronologia_reloj.json`: Registro exacto de fecha, hora, fase diurna y calendario in-world.
* `gestor_reloj.py`: Script para calcular avances temporales y formatear cabeceras canónicas.
