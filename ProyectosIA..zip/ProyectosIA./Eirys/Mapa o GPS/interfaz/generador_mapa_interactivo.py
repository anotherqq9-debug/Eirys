"""
Visor Cartográfico Interactivo de Hinomoto (Eirys 1.0)
Diseño Limpio Sin GPS:
- El mapa artístico en español se visualiza 100% despejado (cero pines, círculos o líneas SVG superpuestas).
- Selector superior e interactivo de botones para navegar entre:
  * Vista Continental Completa
  * Reinos Principales (Shinrai, Yamashiro, Kamishiro, Tatsumigane, Kurokura Jukai)
  * Asentamientos y Ciudades destacadas con sus fichas completas (Definición, Política, Religión, Costumbres)
- Guía interactiva de Flora, Fauna y Recursos endémicos enlazada a cada región.
"""

import os
import sys
import json
import base64

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
ATLAS_JSON = os.path.join(BASE_DIR, "Mapa o GPS", "atlas_geografico.json")
FLORA_FAUNA_JSON = os.path.join(BASE_DIR, "Mapa o GPS", "flora_y_fauna_reinos.json")
IMAGE_PATH = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "mapa_hinomoto_perfeccionado.jpg")
IMAGE_PATH_CANONICO = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "mapa_hinomoto_perfeccionado.jpg")
CROPS_DIR = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "recortes_regionales")
METADATA_JSON = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "recortes_metadata.json")
LOCAL_MAP_HTML = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", "mapa_interactivo.html")

CONV_ID = "d40ad053-d44a-480d-b285-c25fbfd8adcf"
ARTIFACT_DIR = f"/home/vola3s/.gemini/antigravity/brain/{CONV_ID}"
ARTIFACT_MAP_HTML = os.path.join(ARTIFACT_DIR, "mapa_interactivo.html")

def _cargar_b64(path):
    if os.path.exists(path):
        with open(path, "rb") as f:
            return f"data:image/jpeg;base64,{base64.b64encode(f.read()).decode('utf-8')}"
    return ""

def generar_mapa_html():
    if not os.path.exists(ATLAS_JSON):
        print(f"Error: No existe {ATLAS_JSON}")
        return False

    with open(ATLAS_JSON, 'r', encoding='utf-8') as f:
        atlas = json.load(f)

    flora_fauna = {}
    if os.path.exists(FLORA_FAUNA_JSON):
        with open(FLORA_FAUNA_JSON, 'r', encoding='utf-8') as f:
            flora_fauna = json.load(f)

    crops_meta = {}
    if os.path.exists(METADATA_JSON):
        with open(METADATA_JSON, 'r', encoding='utf-8') as f:
            crops_meta = json.load(f)

    img_b64_main = _cargar_b64(IMAGE_PATH)
    img_b64_canon = _cargar_b64(IMAGE_PATH_CANONICO)

    crops_b64 = {}
    for k, info in crops_meta.items():
        fname = info.get("filename", "")
        p = os.path.join(CROPS_DIR, fname)
        if not os.path.exists(p):
            p = os.path.join(BASE_DIR, "Mapa o GPS", "interfaz", fname)
        b64 = _cargar_b64(p)
        if b64:
            crops_b64[k] = b64

    # Lista estructurada de reinos y ciudades para los botones interactivos
    reinos_data = []
    colores_reino = {
        "reino_1_humano_yamashiro": {"color": "#38bdf8", "border": "#0284c7", "tipo": "Reino Humano de Yamashiro (Este)", "crop_key": "yamashiro", "icono": "🏯", "key_ff": "reino_humano_yamashiro"},
        "reino_2_demihumano_kamishiro": {"color": "#4ade80", "border": "#16a34a", "tipo": "Mancomunidad Demihumana de Kamishiro (Sur)", "crop_key": "kamishiro", "icono": "🌲", "key_ff": "reino_demihumano_kamishiro"},
        "reino_3_elfo_shinrai": {"color": "#c084fc", "border": "#9333ea", "tipo": "Reino Soberano Elfo de Shinrai (Norte)", "crop_key": "shinrai", "icono": "🧝", "key_ff": "reino_elfo_shinrai"},
        "reino_4_enano_tatsumigane": {"color": "#fb923c", "border": "#ea580c", "tipo": "Reino Subterráneo Enano de Tatsumigane (Oeste)", "crop_key": "tatsumigane", "icono": "⚒️", "key_ff": "reino_enano_tatsumigane"}
    }

    ciudades_por_reino = {}
    for r_k, r_info in atlas.get("reinos_principales", {}).items():
        est = colores_reino.get(r_k, {"color": "#94a3b8", "border": "#64748b", "tipo": "Reino", "crop_key": "kurokura", "icono": "📍", "key_ff": ""})
        ciudades_por_reino[est["crop_key"]] = []
        for c_k, c_data in r_info.get("ciudades_y_pueblos", {}).items():
            ciudades_por_reino[est["crop_key"]].append({
                "id": c_k,
                "nombre": c_data.get("nombre", "").split("(")[0].strip(),
                "nombre_completo": c_data.get("nombre", ""),
                "tipo": c_data.get("tipo", ""),
                "reino": est["tipo"],
                "reino_key": est["crop_key"],
                "color": est["color"],
                "icono": est["icono"],
                "key_ff": est["key_ff"],
                "distancia_km": c_data.get("distancia_izaya_km", 0),
                "definicion": c_data.get("definicion", ""),
                "religion": c_data.get("religion", r_info.get("religion_predominante", "")),
                "sistema_politico": c_data.get("sistema_politico", r_info.get("sistema_politico", "")),
                "costumbres": c_data.get("costumbres", r_info.get("costumbres_clave", ""))
            })

    # Continente demoniaco
    dem = atlas.get("continente_inexplorado", {})
    if dem:
        ciudades_por_reino.setdefault("magatsukuni", []).append({
            "id": "magatsukuni",
            "nombre": "Magatsukuni",
            "nombre_completo": dem.get("nombre", ""),
            "tipo": "Continente Demoniaco Inexplorado",
            "reino": "Mundo Oscuro / Abisal (Sureste)",
            "reino_key": "magatsukuni",
            "color": "#f43f5e",
            "icono": "🌑",
            "key_ff": "",
            "distancia_km": 850,
            "definicion": dem.get("estado", ""),
            "religion": dem.get("religion", ""),
            "sistema_politico": dem.get("sistema_politico", ""),
            "costumbres": dem.get("costumbres", "")
        })

    ciudades_json_str = json.dumps(ciudades_por_reino, ensure_ascii=False)
    flora_fauna_json_str = json.dumps(flora_fauna, ensure_ascii=False)
    crops_json_str = json.dumps(crops_b64, ensure_ascii=False)
    meta_json_str = json.dumps(crops_meta, ensure_ascii=False)

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Atlas Cartográfico de Hinomoto - Eirys 1.0</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <style>
    body {{
      background: var(--background, #080d1a);
      color: var(--foreground, #e2e8f0);
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow-x: hidden;
    }}
    .map-canvas-container {{
      background: #0b1120;
      box-shadow: inset 0 0 60px rgba(0, 0, 0, 0.9);
    }}
    .glow-pulse {{
      animation: pulse-ring 2.2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }}
    @keyframes pulse-ring {{
      0%, 100% {{ transform: scale(1); opacity: 1; }}
      50% {{ transform: scale(1.45); opacity: 0.3; }}
    }}
    .map-bg-image {{
      opacity: 0.99;
      filter: contrast(1.03) saturate(1.08);
    }}
  </style>
</head>
<body class="p-3 md:p-6 bg-transparent antialiased">
  <div class="max-w-7xl mx-auto space-y-4">
    
    <!-- Barra Superior de Navegación por Reinos -->
    <div class="bg-[var(--card,#0f172a)] border border-[var(--border,#334155)] rounded-2xl p-4 shadow-xl flex flex-wrap justify-between items-center gap-4">
      <div class="flex items-center gap-3">
        <span class="text-3xl">🧭</span>
        <div>
          <h1 class="text-xl md:text-2xl font-black tracking-wide text-cyan-400">ATLAS CARTOGRÁFICO DE HINOMOTO</h1>
          <p class="text-xs text-[var(--muted-foreground,#94a3b8)]">Visor Limpio y Navegación Regional por Botones • Eirys 1.0</p>
        </div>
      </div>
      
      <!-- Botones Principales de Vistas de Reinos -->
      <div class="flex flex-wrap items-center gap-2 text-xs">
        <button id="btn-continental" onclick="verMapaCompleto()" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-700 text-white font-bold hover:bg-cyan-600 transition cursor-pointer shadow">
          🌐 Vista Continental
        </button>
        <button id="btn-shinrai" onclick="zoomRegion('shinrai')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-950/80 border border-purple-500/50 text-purple-300 font-semibold hover:bg-purple-900/60 transition cursor-pointer shadow">
          <span class="w-2.5 h-2.5 rounded-full bg-purple-400"></span> Shinrai (Norte)
        </button>
        <button id="btn-yamashiro" onclick="zoomRegion('yamashiro')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-950/80 border border-sky-500/50 text-sky-300 font-semibold hover:bg-sky-900/60 transition cursor-pointer shadow">
          <span class="w-2.5 h-2.5 rounded-full bg-sky-400"></span> Yamashiro (Este)
        </button>
        <button id="btn-kamishiro" onclick="zoomRegion('kamishiro')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-semibold hover:bg-emerald-900/60 transition cursor-pointer shadow">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Kamishiro (Sur)
        </button>
        <button id="btn-tatsumigane" onclick="zoomRegion('tatsumigane')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-950/80 border border-orange-500/50 text-orange-300 font-semibold hover:bg-orange-900/60 transition cursor-pointer shadow">
          <span class="w-2.5 h-2.5 rounded-full bg-orange-400"></span> Tatsumigane (Oeste)
        </button>
        <button id="btn-kurokura" onclick="zoomRegion('kurokura')" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-950/90 border border-amber-500/70 text-amber-300 font-bold hover:bg-amber-900/60 transition cursor-pointer shadow">
          <span class="w-2.5 h-2.5 rounded-full bg-amber-400 glow-pulse"></span> Kurokura (Centro / Tú)
        </button>
        <button id="btn-toggle-labels" onclick="alternarRotulos()" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 border border-cyan-500/50 text-cyan-300 font-bold hover:bg-slate-700 transition cursor-pointer shadow ml-auto">
          🏷️ <span id="label-mode-text">Ocultar Nombres</span>
        </button>
      </div>
    </div>

    <!-- Barra Dinámica de Asentamientos del Reino Activo -->
    <div id="subnav-ciudades" class="bg-[var(--card,#0f172a)] border border-[var(--border,#334155)] rounded-xl p-3 shadow-md flex flex-wrap items-center gap-2">
      <span class="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">📍 Lugares y Ciudades:</span>
      <div id="subnav-buttons-container" class="flex flex-wrap items-center gap-2 text-xs">
        <!-- Generado dinámicamente -->
      </div>
    </div>

    <!-- Contenedor del Mapa Limpio y Nítido (Proporción Nativa 1024 / 438) -->
    <div id="main-map-box" class="relative w-full aspect-[1024/438] rounded-2xl border border-[var(--border,#334155)] overflow-hidden map-canvas-container shadow-2xl transition-all duration-300">
      
      <!-- Imagen de Fondo (Continental o Recorte Ampliado) -->
      <img id="map-bg-img" src="{img_b64_main}" alt="Mapa de Hinomoto" class="absolute inset-0 w-full h-full object-fill map-bg-image pointer-events-none select-none transition-all duration-500" />

      <!-- Indicador de Región Activa -->
      <div id="zoom-badge" class="hidden absolute top-4 left-4 z-20 bg-slate-900/95 backdrop-blur-md border border-cyan-500/70 px-4 py-2 rounded-xl text-xs flex items-center gap-3 shadow-2xl">
        <span class="text-emerald-400 font-bold">🗺️ REGIÓN ACTIVA:</span>
        <span id="zoom-region-name" class="font-extrabold text-cyan-300 uppercase tracking-wide"></span>
        <button onclick="verMapaCompleto()" class="px-2.5 py-1 bg-cyan-700/80 hover:bg-cyan-600 rounded text-[11px] font-bold text-white transition cursor-pointer">Restablecer Vista Continental</button>
      </div>

      <!-- Panel Flotante Desplegable con Detalles de la Ciudad Seleccionada -->
      <div id="city-modal" class="absolute top-4 right-4 max-w-sm w-full bg-[var(--card,#0f172a)]/95 backdrop-blur-md border border-cyan-500/60 rounded-2xl p-5 shadow-2xl transition-all duration-300 transform translate-x-full opacity-0 pointer-events-none z-30">
        <div class="flex justify-between items-start border-b border-slate-700/80 pb-3">
          <div>
            <span id="modal-badge" class="px-2 py-0.5 text-[10px] font-black uppercase rounded-full tracking-wider">REINO</span>
            <h2 id="modal-title" class="text-lg font-black text-slate-100 mt-1">Nombre del Asentamiento</h2>
            <p id="modal-type" class="text-xs text-cyan-400 font-medium">Tipo</p>
          </div>
          <button onclick="cerrarModal()" class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer">✕</button>
        </div>

        <div class="space-y-3 mt-3 text-xs leading-relaxed max-h-[360px] overflow-y-auto pr-1">
          <div>
            <span class="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block">📜 Definición Geográfica</span>
            <p id="modal-def" class="text-slate-200 mt-0.5"></p>
          </div>
          <div>
            <span class="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block">⛩️ Religión Predominante</span>
            <p id="modal-rel" class="text-slate-200 mt-0.5"></p>
          </div>
          <div>
            <span class="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block">⚖️ Sistema Político</span>
            <p id="modal-pol" class="text-slate-200 mt-0.5"></p>
          </div>
          <div>
            <span class="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block">🎋 Costumbres y Leyes</span>
            <p id="modal-cos" class="text-slate-200 mt-0.5"></p>
          </div>
          <div class="pt-2 border-t border-slate-800 flex justify-between items-center text-[11px]">
            <span class="text-slate-400">Distancia a la posición de Izaya:</span>
            <span id="modal-dist" class="font-mono text-amber-400 font-bold">0 km</span>
          </div>
          <div class="pt-2 flex gap-2">
            <button id="modal-btn-zoom-ciudad" class="flex-1 py-1.5 px-2 bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 rounded-lg text-emerald-300 font-bold text-center block transition cursor-pointer">
              🔍 Ver Detalle en Mapa
            </button>
            <button id="modal-btn-ff" class="flex-1 py-1.5 px-2 bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/50 rounded-lg text-cyan-300 font-bold text-center block transition cursor-pointer">
              🌿 Flora & Fauna
            </button>
          </div>
        </div>
      </div>

    </div>

    <!-- Panel Inferior de Flora, Fauna y Biomas de Hinomoto -->
    <div id="flora-fauna-panel" class="bg-[var(--card,#0f172a)] border border-[var(--border,#334155)] rounded-2xl p-5 shadow-xl space-y-4">
      <div class="flex flex-wrap justify-between items-center gap-2 border-b border-slate-800 pb-3">
        <div>
          <h2 id="ff-reino-title" class="text-lg font-black text-cyan-400 flex items-center gap-2">
            <span>🌿</span> Guía de Flora, Fauna y Recursos de Hinomoto
          </h2>
          <p id="ff-reino-biomas" class="text-xs text-slate-400 mt-0.5">Selecciona una región o reino en los botones para consultar su ecología.</p>
        </div>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5" id="ff-cards-container"></div>
    </div>

    <!-- Barra de Estado Inferior -->
    <div class="bg-[var(--card,#0f172a)] border border-[var(--border,#334155)] rounded-xl p-3 text-xs flex flex-wrap justify-between items-center text-slate-400 gap-2">
      <div class="flex items-center gap-2">
        <span class="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block animate-ping"></span>
        <span class="text-slate-300 font-semibold">Posición de Inicio de Izaya:</span>
        <span class="text-amber-300 font-bold">Dosel del Gran Árbol Centenario (Kurokura Jukai • Centro Continental)</span>
        <span class="text-emerald-400 font-semibold">• Libertad de Tránsito 360° Activa</span>
      </div>
      <div class="text-[11px] text-cyan-400 font-mono">
        Usa los botones superiores para inspeccionar cualquier reino o ciudad sin elementos gráficos que tapen la imagen.
      </div>
    </div>

  </div>

  <script>
    const ciudadesData = {ciudades_json_str};
    const floraFaunaData = {flora_fauna_json_str};
    const cropsData = {crops_json_str};
    const cropsMeta = {meta_json_str};
    const mainMapSrc = "{img_b64_main}";
    const canonMapSrc = "{img_b64_canon}";
    let mostrandoRotulos = true;

    const modal = document.getElementById('city-modal');
    const bgImg = document.getElementById('map-bg-img');
    const zoomBadge = document.getElementById('zoom-badge');
    const zoomRegionName = document.getElementById('zoom-region-name');
    const subnavContainer = document.getElementById('subnav-buttons-container');

    let reinoActivo = 'todos';

    function poblarBotonesCiudades(reinoKey) {{
      subnavContainer.innerHTML = '';
      let lista = [];

      if (reinoKey === 'todos') {{
        Object.keys(ciudadesData).forEach(k => {{
          lista = lista.concat(ciudadesData[k]);
        }});
      }} else if (ciudadesData[reinoKey]) {{
        lista = ciudadesData[reinoKey];
      }}

      lista.forEach(c => {{
        const btn = document.createElement('button');
        btn.className = 'px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 hover:border-cyan-500/50 hover:bg-slate-700 text-slate-200 transition font-medium cursor-pointer flex items-center gap-1.5 shadow-sm';
        btn.innerHTML = `<span style="color: ${{c.color}}">${{c.icono}}</span> ${{c.nombre}}`;
        btn.onclick = () => abrirModalCiudad(c);
        subnavContainer.appendChild(btn);
      }});
    }}

    function abrirModalCiudad(c) {{
      document.getElementById('modal-badge').textContent = c.reino;
      document.getElementById('modal-badge').style.backgroundColor = c.color + '33';
      document.getElementById('modal-badge').style.color = c.color;
      document.getElementById('modal-title').textContent = c.nombre_completo;
      document.getElementById('modal-type').textContent = c.tipo;
      document.getElementById('modal-def').textContent = c.definicion;
      document.getElementById('modal-rel').textContent = c.religion;
      document.getElementById('modal-pol').textContent = c.sistema_politico;
      document.getElementById('modal-cos').textContent = c.costumbres;
      document.getElementById('modal-dist').textContent = c.distancia_km + ' km';

      const btnFF = document.getElementById('modal-btn-ff');
      if (c.key_ff) {{
        btnFF.style.display = 'block';
        btnFF.onclick = () => filtrarFloraFauna(c.key_ff);
      }} else {{
        btnFF.style.display = 'none';
      }}

      const btnZoom = document.getElementById('modal-btn-zoom-ciudad');
      if (cropsData[c.id]) {{
        btnZoom.style.display = 'block';
        btnZoom.onclick = () => zoomCiudad(c.id, c.nombre_completo);
      }} else {{
        btnZoom.style.display = 'none';
      }}

      modal.classList.remove('translate-x-full', 'opacity-0', 'pointer-events-none');
    }}

    function cerrarModal() {{
      modal.classList.add('translate-x-full', 'opacity-0', 'pointer-events-none');
    }}

    function zoomRegion(cropKey) {{
      reinoActivo = cropKey;
      if (cropsData[cropKey] && cropsMeta[cropKey]) {{
        bgImg.src = cropsData[cropKey];
        zoomBadge.classList.remove('hidden');
        zoomRegionName.textContent = cropsMeta[cropKey].nombre;
        poblarBotonesCiudades(cropKey);
      }}
      // Filtrar flora y fauna correspondiente
      const ffs = {{
        'shinrai': 'reino_elfo_shinrai',
        'yamashiro': 'reino_humano_yamashiro',
        'kamishiro': 'reino_demihumano_kamishiro',
        'tatsumigane': 'reino_enano_tatsumigane',
        'kurokura': 'kurokura_jukai_y_salvaje'
      }};
      if (ffs[cropKey]) filtrarFloraFauna(ffs[cropKey]);
    }}

    function zoomCiudad(cityId, nombreCiudad) {{
      if (cropsData[cityId] && cropsMeta[cityId]) {{
        bgImg.src = cropsData[cityId];
        zoomBadge.classList.remove('hidden');
        zoomRegionName.textContent = nombreCiudad || cropsMeta[cityId].nombre;
      }}
    }}

    function verMapaCompleto() {{
      reinoActivo = 'todos';
      bgImg.src = mostrandoRotulos ? mainMapSrc : canonMapSrc;
      zoomBadge.classList.add('hidden');
      poblarBotonesCiudades('todos');
      filtrarFloraFauna('kurokura_jukai_y_salvaje');
    }}

    function alternarRotulos() {{
      mostrandoRotulos = !mostrandoRotulos;
      const btnText = document.getElementById('label-mode-text');
      if (mostrandoRotulos) {{
        btnText.textContent = 'Ocultar Nombres';
        if (reinoActivo === 'todos') {{
          bgImg.src = mainMapSrc;
        }}
      }} else {{
        btnText.textContent = 'Mostrar Nombres';
        if (reinoActivo === 'todos') {{
          bgImg.src = canonMapSrc;
        }}
      }}
    }}

    function filtrarFloraFauna(key) {{
      const data = floraFaunaData[key];
      if (!data) return;

      document.getElementById('ff-reino-title').innerHTML = `<span>🌿</span> Flora y Fauna: ${{data.reino || data.territorio}}`;
      document.getElementById('ff-reino-biomas').innerHTML = `<strong>Biomas nativos:</strong> ${{data.biomas.join(' • ')}}`;

      let floraHtml = '<div class="space-y-3"><h3 class="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5"><span>🌸</span> Flora Nativa & Recursos</h3>';
      data.flora_distintiva.forEach(f => {{
        floraHtml += `
          <div class="p-3 bg-slate-900/90 rounded-xl border border-emerald-900/40 shadow-sm">
            <h4 class="text-xs font-bold text-emerald-300">${{f.nombre}}</h4>
            <p class="text-[11px] text-slate-300 mt-1 leading-relaxed">${{f.descripcion}}</p>
          </div>
        `;
      }});
      floraHtml += '</div>';

      let faunaHtml = '<div class="space-y-3"><h3 class="text-sm font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5"><span>🐺</span> Fauna & Bestias Nativas</h3>';
      data.fauna_distintiva.forEach(a => {{
        faunaHtml += `
          <div class="p-3 bg-slate-900/90 rounded-xl border border-amber-900/40 shadow-sm">
            <h4 class="text-xs font-bold text-amber-300">${{a.nombre}}</h4>
            <p class="text-[11px] text-slate-300 mt-1 leading-relaxed">${{a.descripcion}}</p>
          </div>
        `;
      }});
      faunaHtml += '</div>';

      document.getElementById('ff-cards-container').innerHTML = floraHtml + faunaHtml;
    }}

    // Inicialización limpia
    poblarBotonesCiudades('todos');
    filtrarFloraFauna('kurokura_jukai_y_salvaje');
  </script>
</body>
</html>
"""

    with open(LOCAL_MAP_HTML, 'w', encoding='utf-8') as f:
        f.write(html)

    if os.path.exists(ARTIFACT_DIR):
        try:
            with open(ARTIFACT_MAP_HTML, 'w', encoding='utf-8') as f:
                f.write(html)
        except Exception:
            pass

    print(f"[VISOR CARTOGRÁFICO LIMPIO Y NAVEGACIÓN]: Generado exitosamente en '{LOCAL_MAP_HTML}'")
    return True

if __name__ == "__main__":
    generar_mapa_html()
