# 🗺️ MÓDULO DE MAPA Y CARTOGRAFÍA (EIRYS)

---

## 🎯 PROPÓSITO
Gestiona la **geografía del continente, distancias en kilómetros, rutas de tránsito, coordenadas y puntos de interés**.
Garantiza que los tiempos de viaje sean realistas según la velocidad a pie, a caballo o en bastiones mecanizados.

## 📁 ARCHIVOS
* `atlas_geografico.json`: Matriz de regiones, reinos, capitales, puestos fronterizos y distancias.
* `atlas_interactivo.html`: Visor cartográfico interactivo.
