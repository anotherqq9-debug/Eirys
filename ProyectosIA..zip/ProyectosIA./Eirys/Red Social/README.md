# 🌐 MÓDULO DE RED SOCIAL Y MATRIZ POLÍTICA (EIRYS)

---

## 🎯 PROPÓSITO
Mapea la **red de relaciones interpersonales, niveles de lealtad, deudas de honor, reputación de facciones y tratados políticos**.
Previene inconsistencias sobre quién confía en quién, quién debe favores y qué tratados están en vigor.

## 📁 ARCHIVOS
* `matriz_relaciones_sociales.json`: Relaciones cruzadas de afinidad, lealtad y compromisos.
* `organigrama_politico.md`: Jerarquía visual de mandos y alianzas geopolíticas.
