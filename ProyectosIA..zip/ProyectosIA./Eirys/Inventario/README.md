# 🎒 MÓDULO DE INVENTARIO Y RECURSOS FINITOS (EIRYS)

---

## 🎯 PROPÓSITO
Constituye la **fuente de verdad económica, material y de equipamiento**.
Aplica la Regla de Recursos Finitos: nada se duplica, nada desaparece y las monedas se cuentan con exactitud matemática.

## 📁 ARCHIVOS
* `estado_inventario.json`: Contabilidad exacta de tesorería (Oro, Plata, Cobre), equipo activo, almacenamiento dimensional y consumibles.
* `gestor_inventario.py`: Script para añadir, gastar, transferir y auditar recursos con tolerancia cero a discrepancias.
